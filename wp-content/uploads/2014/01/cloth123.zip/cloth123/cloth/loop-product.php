<div class="product-item column col3">
			
			<div class="product-thumbnail">
				<?php colabs_image('width=305&height=315&link=img');?>	
				<?php if(wpsc_product_external_link(wpsc_the_product_id()) != '') : ?>
				<?php $action =  wpsc_product_external_link(wpsc_the_product_id()); ?>
				<?php else: ?>
				<?php $action = htmlentities(wpsc_this_page_url(), ENT_QUOTES, 'UTF-8' ); ?>					
				<?php endif; ?>
				<form class="product_form"  enctype="multipart/form-data" action="<?php echo $action; ?>" method="post" name="product_<?php echo wpsc_the_product_id(); ?>" id="product_<?php echo wpsc_the_product_id(); ?>" >
				<?php do_action ( 'wpsc_product_form_fields_begin' ); ?>
					<input type="hidden" value="add_to_cart" name="wpsc_ajax_action"/>
					<input type="hidden" value="<?php echo wpsc_the_product_id(); ?>" name="product_id"/>
					<?php if((get_option('hide_addtocart_button') == 0) &&  (get_option('addtocart_or_buynow') !='1')) : ?>
						<?php if(wpsc_product_has_stock()) : ?>
								<div class="wpsc_buy_button_container">
								<?php if(wpsc_product_external_link(wpsc_the_product_id()) != '') : ?>
									<input class="wpsc_buy_button" type="submit" value="<?php echo wpsc_product_external_link_text( wpsc_the_product_id(), __( 'Buy Now', 'wpsc' ) ); ?>" onclick="return gotoexternallink('<?php echo $action; ?>', '<?php echo wpsc_product_external_link_target( wpsc_the_product_id() ); ?>')">
								<?php else: ?>
									<input type="submit" value="<?php _e('Add To Cart','colabsthemes'); ?>" name="Buy" class="wpsc_buy_button button yellow cart dark" id="product_<?php echo wpsc_the_product_id(); ?>_submit_button"/>
								<?php endif; ?>
								</div><!--close wpsc_buy_button_container-->
						<?php endif ; ?>
					<?php endif ; ?>								
				<?php do_action ( 'wpsc_product_form_fields_end' ); ?>
				</form>						
				<a href="<?php the_permalink(); ?>" class="btn-details"><?php _e('See Details','colabsthemes');?></a>
			</div><!-- product-thumbnail -->

			<div class="product-header">
				<h3 class="product-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<span class="product-price"><span class="amount"><?php echo wpsc_the_product_price(); ?></span></span>
			</div><!-- .product-header -->

</div><!-- .product-item -->
