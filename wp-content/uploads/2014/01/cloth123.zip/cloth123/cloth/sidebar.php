<?php
/**
 * Sidebar Template
 *
 * If a `primary` widget area is active and has widgets, display the sidebar.
 *
 * @package CoLabsFramework
 * @subpackage Template
 */
	global $colabs_options;
	
	$layout = $colabs_options['colabs_layout'];
	
	if ( $layout != 'one-col' ) {

		if ( colabs_active_sidebar( 'primary' ) ) {
	
			colabs_sidebar_before();
?>
<div class="sidebar column col3">
	<?php
		colabs_sidebar_inside_before();
		colabs_sidebar('primary');
		colabs_sidebar_inside_after();
	?>
</div><!-- /#sidebar -->
<?php
			colabs_sidebar_after();
		} // End IF Statement
	} // End IF Statement
?>