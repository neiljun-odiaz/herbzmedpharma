<?php if(isset($cart_messages) && count($cart_messages) > 0) { ?>
	<?php foreach((array)$cart_messages as $cart_message) { ?>
	  <span class="cart_message"><?php echo esc_html( $cart_message ); ?></span>
	<?php } ?>
<?php } ?>

<?php if(wpsc_cart_item_count() > 0): ?>
	<div class="widget_shopping_cart top-cart" style="display: none;">
	<h2><?php _e('Cart', 'colabsthemes'); ?></h2>
		<ul class="cart_list product_list_widget hide_cart_widget_if_empty">
			<?php while(wpsc_have_cart_items()): wpsc_the_cart_item(); ?>
			<li>
			<?php do_action ( "wpsc_before_cart_widget_item_name" ); ?>
			<a href="<?php echo wpsc_cart_item_url(); ?>">
			<?php echo wpsc_cart_item_name(); ?>
			</a>
			<?php do_action ( "wpsc_after_cart_widget_item_name" ); ?>
			<span class="quantity"><?php echo wpsc_cart_item_quantity(); ?> <span class="amount"><?php echo wpsc_cart_item_price(); ?></span></span>
			<form action="" method="post" class="adjustform">
					<input type="hidden" name="quantity" value="0" />
					<input type="hidden" name="key" value="<?php echo wpsc_the_cart_item_key(); ?>" />
					<input type="hidden" name="wpsc_update_quantity" value="true" />
					<input class="remove_button" type="submit" value="&times;" />
			</form>
			</li>
			<?php endwhile; ?>
		</ul>
		<p class="total"><strong><?php _e('Subtotal', 'colabsthemes'); ?>:</strong> <span class="amount"><?php echo wpsc_cart_total_widget( false, false ,false ); ?></span></p>
		<p class="buttons">
		<a class="button checkout" href="<?php echo get_option('shopping_cart_url'); ?>"><?php _e('Checkout', 'wpsc'); ?></a>
		</p>
	</div>
   
<?php endif; ?>

<?php
wpsc_google_checkout();


?>
