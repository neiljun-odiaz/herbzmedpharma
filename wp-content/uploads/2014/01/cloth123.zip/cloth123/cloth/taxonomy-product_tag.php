<?php get_header(); 
global $colabs_posttype,$colabs_taxonomy,$plugin;?>
<?php colabs_content_before(); ?>
<div class="bg-main container">
	<div class="row">
		<div class="main columns col12">
			<?php colabs_breadcrumbs();?>
			<?php if($plugin=='wpsc'){
				global $wp_query;	
				$image_width = get_option('product_image_width');
				?>										
				<h2 class="entry-title"><?php the_title();?></h2>
				<div class="row product-list">
					<?php while (wpsc_have_products()) :  wpsc_the_product(); ?>
						<?php colabs_get_template_part( 'loop', 'product' );?>
					<?php endwhile;?>			
				</div>
			<?php }else if($plugin=='woo'){?>
	
				<?php do_action('woocommerce_before_main_content'); ?>
		
				<?php colabs_shop_filter();?>

				<?php woocommerce_get_template_part( 'loop', 'shop' ); ?>

				<?php do_action('woocommerce_after_main_content'); ?>
				
			<?php }else if($plugin=='jigoshop'){?>
				<?php $term = get_term_by( 'slug', get_query_var($wp_query->query_vars['taxonomy']), $wp_query->query_vars['taxonomy']); ?>

		<h1 class="page-title"><?php echo wptexturize($term->name); ?></h1>

		<?php echo wpautop(wptexturize($term->description)); ?>
		
		<?php
			echo '<div class="row shop-filter">';
				/* Category Product Widget */
				$Widget_Product = new Jigoshop_Widget_Product_Categories();	
				$args = array(
					'before_title' => '',
					'after_title' => '',
					'before_widget' => '<div class="woocommerce_ordering">',
					'after_widget' => '</div>'
				);
				
				$instance = array(
					'title' 	=> ' ',
					'dropdown'	=> true
					
				);
				$Widget_Product->widget( $args, $instance );
				
				/* Price Filter Widget */
				$Widget_Price = new Jigoshop_Widget_Price_Filter();	
				$args = array(
					'before_title' => '<h4 class="widget-title">',
					'after_title' => '</h4>',
					'before_widget' => '<div class="col4 widget_price_filter">',
					'after_widget' => '</div>'
				);
				
				$instance = array(
					'title' => ''		
				);
				$Widget_Price->widget( $args, $instance );
				
				/* Product Search Widget */
				$Product_Search = new CoLabs_Product_Search();	
				$args = array(
					'before_title' => '<h4 class="widget-title">',
					'after_title' => '</h4>',
					'before_widget' => '<div class="col4 widget_colabs_product_search">',
					'after_widget' => '</div>'
				);
				
				$instance = array(
					'title' => ''		
				);
				$Product_Search->widget( $args, $instance );
				echo '</div>';
		?>
				<?php jigoshop_get_template_part( 'loop', 'shop' );?>
			
			<?php }?>
			<?php colabs_pagination();?><!-- .pagination -->
		</div><!-- .main -->
	</div><!-- .container -->
</div><!-- .bg-main -->
<?php colabs_content_after(); ?>

<?php get_footer(); ?>		
