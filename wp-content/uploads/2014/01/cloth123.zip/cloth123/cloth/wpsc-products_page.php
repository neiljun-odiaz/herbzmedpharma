<?php
global $wp_query;	
$image_width = get_option('product_image_width');
/*
 * Most functions called in this page can be found in the wpsc_query.php file
 */
?>

<?php colabs_breadcrumbs();?>						
<h2 class="entry-title"><?php the_title();?></h2>
<div class="row product-list">
	<?php while (wpsc_have_products()) :  wpsc_the_product(); ?>
		<?php colabs_get_template_part( 'loop', 'product' );?>
	<?php endwhile;?>			
</div>

<div class="wpsc-pagination">
<?php wpsc_pagination();//colabs_pagination();?><!-- .pagination -->
</div>
		
