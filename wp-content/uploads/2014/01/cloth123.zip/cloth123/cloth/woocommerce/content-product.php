<?php 
global $product, $woocommerce_loop;

// Store loop count we're currently on
if ( empty( $woocommerce_loop['loop'] ) )
	$woocommerce_loop['loop'] = 0;

// Store column count for displaying the grid
if ( empty( $woocommerce_loop['columns'] ) )
	$woocommerce_loop['columns'] = apply_filters( 'loop_shop_columns', 4 );

// Ensure visibilty
if ( ! $product->is_visible() )
	return;

// Increase loop count
$woocommerce_loop['loop']++;
		
?>
<div class="product-item column col3 <?php
	if ( $woocommerce_loop['loop'] % $woocommerce_loop['columns'] == 0 )
		echo 'last';
	elseif ( ( $woocommerce_loop['loop'] - 1 ) % $woocommerce_loop['columns'] == 0 )
		echo 'first';
	?>">
	<?php if ($product->is_on_sale()) : ?>
		<?php echo apply_filters('woocommerce_sale_flash', '<span class="product-discount">'.__('On Sale!', 'woocommerce').'</span>', $post, $product); ?>
	<?php endif; ?>

	<div class="product-thumbnail">
		<?php colabs_image('width=305&height=315&link=img');?>
		<a href="<?php echo $product->add_to_cart_url(); ?>" class="btn-cart"><?php _e('Add To Cart','colabsthemes');?></a>
		<a href="<?php the_permalink(); ?>" class="btn-details"><?php _e('See Details','colabsthemes');?></a>
	</div><!-- product-thumbnail -->

	<div class="product-header">
		<h3 class="product-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<span class="product-price"><?php echo $product->get_price_html(); ?></span>
	</div><!-- .product-header -->

</div><!-- .product-item -->
