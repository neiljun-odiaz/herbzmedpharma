<?php
/**
 * Footer Template
 *
 * Here we setup all logic and XHTML that is required for the footer section of all screens.
 *
 * @package CoLabsFramework
 * @subpackage Template
 */
 

    
?>
	<div class="bg-main-bottom container">
		<div class="row">
		&nbsp;
		</div>
	</div><!-- .bg-main-bottom -->
	<div class="bg-sidefooter container">
	<div class="row">
		<div class="sidefooter columns col12">
			<?php 
			wp_reset_query();			
			colabs_footer_top();		 
			colabs_footer_before(); 
			colabs_footer_inside();			
			colabs_footer_after();  
			?>
		</div><!-- .sidefooter -->	
	</div><!-- .container -->
	</div><!-- .bg-sidefooter -->
	
	<div class="bg-footer container">
	<div class="row">
		<div class="footer columns col12">
			<p class="column col7"><?php colabs_credit(); ?></p>
			<div class="column col5">
				<ul class="menu fr">
					<li><img src="<?php bloginfo('stylesheet_directory'); ?>/images/paypal.png" /></li>
					<li><img src="<?php bloginfo('stylesheet_directory'); ?>/images/mastercard.png" /></li>
					<li><img src="<?php bloginfo('stylesheet_directory'); ?>/images/visa.png" /></li>
				</ul>
			</div>
		</div><!-- .footer -->
	</div><!-- .container -->
	</div><!-- .bgfooter --> 
</div><!-- .wrapper -->
<?php wp_footer(); ?>
<?php colabs_foot(); ?>
</body>
</html>