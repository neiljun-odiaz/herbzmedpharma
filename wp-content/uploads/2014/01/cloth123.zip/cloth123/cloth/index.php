<?php get_header(); 
global $colabs_options,$colabs_posttype,$colabs_taxonomy,$plugin;?>
<?php
	wp_reset_query();
	$headline = get_option('colabs_headline_product');
	$headline_limit= get_option('colabs_headline_limit');
	$exclude=array();
	if($headline_limit=='')$headline_limit=3;
	query_posts( array(
				'showposts' => $headline_limit,
				'post_type' => $colabs_posttype,
				'tax_query' => array(
									array(
									'taxonomy' => $colabs_taxonomy,
									'field' => 'id',
									'terms' => $headline
									)
								)
	));
	if ( have_posts() ):
?>
<div class="bg-slider container">
	<div class="row">
		<div class="flex-container column col12">
			<div class="flexslider">
				<ul class="slides">
				<?php while ( have_posts() ) : the_post();?>
					<li>
						<?php colabs_image('width=355&height=302&class=fr');?>
						<div class="flex-caption fl">
						<h3 class="caption-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<?php colabs_product_excerpt(); ?>
						<p class="product-brand"><?php 
						if(get_post_meta($post->ID,'_product_attributes',true)){
						$att=get_post_meta($post->ID,'_product_attributes',true);
						echo $att['brand']['value'];
						}
						?></p>
						</div>
					</li>
				<?php 
				$exclude[]=$post->ID;
				endwhile;?>	
				</ul>
			</div><!-- .flexslider -->
		</div><!-- .flex-container -->
	</div><!-- .container -->
</div><!-- .bg-slider -->
<?php endif;?>
	<div class="bg-main container">
	<div class="row">
		<div class="main columns col12">
		
			<div class="content column col9">
				
				<?php
				$limit=get_option('colabs_new_arrivals_limit');
				if(empty($limit))$limit=5;
				if($plugin=='wpsc'){
				$featured = get_option('sticky_products');
				$exclude=array_merge((array)$exclude, (array)$featured);
				$arg = array(
							'post__not_in' 		=> $exclude,
							'post_type' 		=> $colabs_posttype,
							'showposts' 		=> $limit
						);
				}else if($plugin=='jigoshop'){
				$featured=array();
				$args = array(
							'post_type' 		=> $colabs_posttype,
							'meta_key'			=> 'featured',
							'meta_value'		=> '1'
				);	
				$featureds = get_posts( $args );		
				foreach ($featureds as $item_featured){
				$featured[]=$item_featured->ID;
				}
				$exclude=array_merge((array)$exclude, (array)$featured);				
				$arg = array(
							'post__not_in' 		=> $exclude,
							'post_type' 		=> $colabs_posttype,
							'showposts' 		=> $limit
						);
				/* $arg = array(
					'showposts'=> $limit,
					'post_type'     => 'product',
					'post_status'   => 'publish',
					'meta_key'      => 'featured',
					'meta_value'    => '1',
					'meta_query'    => array(
						array(
							'key'    => 'visibility',
							'value'  => array('catalog', 'visible'),
							'compare'=> 'NOT IN',
						),
					)
				);		 */

				}else if($plugin=='woo'){
					$arg = array(
							'post__not_in' 		=> $exclude,
							'post_type' 		=> $colabs_posttype,
							'meta_key'			=> '_featured',
							'meta_value'		=> 'no',
							'showposts' 		=> $limit
						);
				}else {
					$sticky = get_option( 'sticky_posts' );
					$exclude=array_merge((array)$exclude, (array)$sticky);
					$arg = array(
							'post__not_in' 		=> $exclude,
							'post_type' 		=> $colabs_posttype,
							'showposts' 		=> $limit
						);
				}
			
				query_posts($arg);
				if ( have_posts() ):
				?>
				<div class="homepost row">
					<h2>
						<?php _e('New Arrivals','colabsthemes');?>
						<?php if(!empty($colabs_options['colabs_new_product'])){?>
						&nbsp;|&nbsp;<span class="view"><a href="<?php echo get_permalink($colabs_options['colabs_new_product']);?>"><?php _e('view all','colabsthemes');?></a></span>
						<?php }?>
					</h2>
					<ul class="listproduct">
						<?php while ( have_posts() ) : the_post();?>
						<li><?php colabs_image('width=119&height=120');?></li>
					<?php endwhile;?>
					</ul>
				</div><!-- .homeproduct -->
				<?php endif;?>
				
				<?php
				$featuredlimit=get_option('colabs_featured_limit');
				if(empty($featuredlimit))$featuredlimit=5;
				if($plugin=='wpsc'){
					$featured = get_option('sticky_products');
					$arg = array(
								'post__in' 			=> $featured,
								'post_type' 		=> $colabs_posttype,
								'showposts' 		=> $featuredlimit
							 );
				}else if($plugin=='jigoshop'){

				 $arg = array(
							'post_type' 		=> $colabs_posttype,
							'meta_key'			=> 'featured',
							'meta_value'		=> '1',
							'showposts' 		=> $featuredlimit
						 );

				}else if($plugin=='woo'){
					$arg = array(
							'post_type' 		=> $colabs_posttype,
							'meta_key'			=> '_featured',
							'meta_value'		=> 'yes',
							'showposts' 		=> $featuredlimit
						 );
				}else {
					$arg = array(
							'post_type' 		=> $colabs_posttype,
							'showposts' 		=> $featuredlimit
						 );
				}
				query_posts($arg);
				if ( have_posts() ):
				?>
				<hr class="separator">

				<div class="homepost row">
					<h2>
						<?php _e('Featured Products','colabsthemes');?>
						<?php if(!empty($colabs_options['colabs_featured_product'])){?>
						&nbsp;|&nbsp;<span class="view"><a href="<?php echo get_permalink($colabs_options['colabs_featured_product']);?>"><?php _e('view all','colabsthemes');?></a></span>
						<?php }?>
					</h2>
					<ul class="listproduct">
					<?php while ( have_posts() ) : the_post();?>
						<li><?php colabs_image('width=119&height=120');?></li>
					<?php endwhile;?>
					</ul>
				</div><!-- .homeproduct -->
				
				<?php endif;?>
				
				<?php
				$latestlimit=get_option('colabs_latest_limit');
				if(empty($latestlimit))$latestlimit=2;
				$arg = array(
						'showposts' => $latestlimit
						);
			
				query_posts($arg);
				if ( have_posts() ):
				?>
				<hr class="separator">
				
				<div class="homepost row">
					<h2>
						<?php _e('Latest Blog Posts','colabsthemes');?>
						<?php if(!empty($colabs_options['colabs_blog_post'])){?>
						&nbsp;|&nbsp;<span class="view"><a href="<?php echo get_permalink($colabs_options['colabs_blog_post']);?>"><?php _e('view all','colabsthemes');?></a></span>
						<?php }?>
					</h2>
					<div class="row">
					<?php while ( have_posts() ) : the_post();?>
					<div class="blog column col6">
						<div class="entryblog">
							<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
							<?php the_excerpt();?>
							<p><a href="<?php the_permalink(); ?>"><?php _e('Full Story &raquo;','colabsthemes');?></a></p>
						</div>
						<div class="commentblog">
							<a href="<?php comments_link(); ?>" title=""><?php comments_number( __('0','colabsthemes'), __('1','colabsthemes'), __('%','colabsthemes') ); ?></a>
							<span><?php _e('comments','colabsthemes');?></span>
						</div>
					</div>
					<?php endwhile;?>
					</div>
				</div><!-- .homeproduct -->
				<?php endif;?>

			</div><!-- .content -->

			<?php get_sidebar('home'); ?>

		</div><!-- .main -->
	</div><!-- .container -->
	
	
	</div><!-- .bg-main -->

<?php get_footer(); ?>