<!doctype html>
<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7 ie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8 ie7" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9 ie8" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html <?php language_attributes(); ?>> <!--<![endif]-->

<head profile="http://gmpg.org/xfn/11">
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<title><?php if ( function_exists( 'colabs_title') ){ colabs_title(); }else{ echo get_bloginfo('name'); ?>&nbsp;<?php wp_title(); } ?></title>
	<?php
	if ( function_exists( 'colabs_meta') ) colabs_meta();
	if ( function_exists( 'colabs_meta_head') )colabs_meta_head(); 
	?>
	<link href="<?php bloginfo('stylesheet_directory'); ?>/includes/css/colabs-css.css" rel="stylesheet" type="text/css" />    
	    
	<?php wp_head();?>
	<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
	<?php if ( function_exists( 'colabs_head') ) colabs_head();
	
	$site_title = get_bloginfo( 'name' );
	$site_url = home_url( '/' );
	$site_description = get_bloginfo( 'description' );  
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	global $colabs_posttype,$colabs_taxonomy,$woocommerce,$plugin,$colabs_options;
	if (is_plugin_active('wp-e-commerce/wp-shopping-cart.php')) {
		$colabs_posttype='wpsc-product';
		$colabs_taxonomy='wpsc_product_category';
		$plugin='wpsc';
	}else if (is_plugin_active('jigoshop/jigoshop.php')){
		$colabs_posttype='product';
		$colabs_taxonomy='product_cat';
		$plugin='jigoshop';
	}else if (is_plugin_active('woocommerce/woocommerce.php')){
		$colabs_posttype='product';
		$colabs_taxonomy='product_cat';	
		$plugin='woo';
	}else{
		$colabs_posttype='post';
		$colabs_taxonomy='category';
		$plugin='';
	}	
	?>
	
	<?php if(get_option('colabs_disable_mobile')=='false'){?>
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<?php }?>

</head>
<body <?php body_class(); ?>>
 <div class="wrapper">

	<div class="bg-header container">	
	<div class="row">
		<div class="header column col3 fl">
			<h1>
			<?php
				if (get_option('colabs_logotitle')=='logo'){
				  if (get_option('colabs_logo') ) {
					echo '<a href="' . $site_url . '" title="' . $site_description . '"><img src="' . get_option('colabs_logo') . '" alt="' . $site_title . '" /></a>';
				  } 
				} else { ?>				
				  <a href="<?php echo $site_url; ?>" title="<?php echo $site_title; ?>">
					<h1><?php echo $site_title; ?></h1>
				  </a>
			<?php } ?>
			</h1>
			<?php 
			if($site_description){
			echo '<p class="tagline">'.$site_description.'</p>';
			}
			?>
			
		</div><!-- .header -->

		
		<?php wp_nav_menu( array( 'theme_location' => 'main-menu', 'fallback_cb'=>'colabs_nav_fallback', 'container_class' => 'navigation column col9 fr', 'menu_class' => 'menu fr') );?>
			
		
	</div><!-- .container -->	
	</div><!-- .bg-header -->
	
	<div class="bg-cartheader container">	
	<div class="row">
		<div class="arrow-cart col12">
			<?php if ($plugin=='woo') {?>
						<a href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'colabsthemes'); ?>">
							<span> 
							<?php 
							echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'colabsthemes'), $woocommerce->cart->cart_contents_count);
							?>
							</span>
						</a>
				<?php }elseif ($plugin=='jigoshop'){?>
					<?php colabs_headercart();?>
				<?php }elseif($plugin=='wpsc'){?>
					<a target="_parent" href="<?php echo get_option('shopping_cart_url'); ?>" title="<?php _e('Checkout', 'wpsc'); ?>">
					<span><?php printf( _n('%d item', '%d items', wpsc_cart_item_count(), 'colabsthemes'), wpsc_cart_item_count() ); ?></span>
					</a>
			<?php }?>	

			<?php
			if ($plugin=='woo') {
				/* Cart Widget */
				$Cart_Widget = new WooCommerce_Widget_Cart();	
				$args = array(
					'before_title' => '<h2>',
					'after_title' => '</h2>',
					'before_widget' => '<div class="widget_shopping_cart top-cart">',
					'after_widget' => '</div>'
				);
				
				$instance = array(
					'title' => '',
					'hide_if_empty' => 1	
				);
				$Cart_Widget->widget( $args, $instance );
			}elseif($plugin=='wpsc'){
				include( wpsc_get_template_file_path( 'wpsc-cart_widget.php' ) );
			}elseif ($plugin=='jigoshop'){
				/* Cart Widget */
				$Cart_Widget = new Jigoshop_Widget_Cart();	
				$args = array(
					'before_title' => '<h2>',
					'after_title' => '</h2>',
					'before_widget' => '<div class="widget_shopping_cart top-cart">',
					'after_widget' => '</div>'
				);
				
				$instance = array(
					'title' => '',
					'hide_if_empty' => 1	
				);
				$Cart_Widget->widget( $args, $instance );
			}
			?>
				
		</div>
	</div><!-- .container -->	
	</div><!-- .bg-cartheader -->	
	  