<?php
do_action('jigoshop_before_shop_loop');
?>
<div class="row product-list">
	
	<?php if (have_posts()) : while (have_posts()) : the_post(); $_product = new jigoshop_product( $post->ID );	?>
		<div class="product-item column col3">
			<?php if ($_product->is_on_sale()) {?>
					<?php echo '<span class="product-discount">'.__('On Sale!', 'jigoshop').'</span>'; ?>
			<?php }?>
			<div class="product-thumbnail">
				<?php colabs_image('width=305&height=315&link=img');?>
				<a href="<?php echo $_product->add_to_cart_url(); ?>" class="btn-cart"><?php _e('Add To Cart','colabsthemes');?></a>
				<a href="<?php the_permalink(); ?>" class="btn-details"><?php _e('See Details','colabsthemes');?></a>
			</div><!-- product-thumbnail -->

			<div class="product-header">
				<h3 class="product-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<span class="product-price"><?php echo $_product->get_price_html(); ?></span>
			</div><!-- .product-header -->

		</div><!-- .product-item -->
	<?php 
	endwhile; 
	
	else :
		echo '<p class="info">'.__('No products found which match your selection.', 'jigoshop').'</p>';
	endif;
	
	?>

</div>
<?php
do_action('jigoshop_after_shop_loop');
?>
