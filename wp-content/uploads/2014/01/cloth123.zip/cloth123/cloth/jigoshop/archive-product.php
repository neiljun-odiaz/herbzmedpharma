<?php get_header('shop'); ?>
<div class="bg-main container">
<div class="main row">
	<div id="content" class="column col12">
		
		<?php colabs_breadcrumbs();?>
			
		<?php do_action('jigoshop_before_main_content'); ?>
		
		<?php if (is_search()) : ?>
			<h1 class="page-title"><?php _e('Search Results:', 'jigoshop'); ?> &ldquo;<?php the_search_query(); ?>&rdquo; <?php if (get_query_var('paged')) echo ' &mdash; Page '.get_query_var('paged'); ?></h1>
		<?php else : ?>
			<h1 class="page-title"><?php _e('All Products', 'jigoshop'); ?></h1>
		<?php endif; ?>
		
		<?php
		$shop_page_id = jigoshop_get_page_id('shop');
		$shop_page = get_post($shop_page_id);
		echo apply_filters('the_content', $shop_page->post_content);
		?>
		<?php
			echo '<div class="row shop-filter">';
				/* Category Product Widget */
				$Widget_Product = new Jigoshop_Widget_Product_Categories();	
				$args = array(
					'before_title' => '',
					'after_title' => '',
					'before_widget' => '<div class="woocommerce_ordering">',
					'after_widget' => '</div>'
				);
				
				$instance = array(
					'title' 	=> ' ',
					'dropdown'	=> true
					
				);
				$Widget_Product->widget( $args, $instance );
				
				/* Price Filter Widget */
				$Widget_Price = new Jigoshop_Widget_Price_Filter();	
				$args = array(
					'before_title' => '<h4 class="widget-title">',
					'after_title' => '</h4>',
					'before_widget' => '<div class="col4 widget_price_filter">',
					'after_widget' => '</div>'
				);
				
				$instance = array(
					'title' => ''		
				);
				$Widget_Price->widget( $args, $instance );
				
				/* Product Search Widget */
				$Product_Search = new CoLabs_Product_Search();	
				$args = array(
					'before_title' => '<h4 class="widget-title">',
					'after_title' => '</h4>',
					'before_widget' => '<div class="col4 widget_colabs_product_search">',
					'after_widget' => '</div>'
				);
				
				$instance = array(
					'title' => ''		
				);
				$Product_Search->widget( $args, $instance );
				echo '</div>';
		?>
		
		<?php jigoshop_get_template_part( 'loop', 'shop' ); ?>

		<?php do_action('jigoshop_after_main_content'); ?>
		
		<?php colabs_pagination();?><!-- .pagination -->
		
		
		
	</div><!-- #content -->
</div><!-- .main -->
</div>
<?php get_footer('shop'); ?>
