<?php
/**
 * Template Name: Blog
 *
 * The Blog page template displays your posts with a "Blog"-style
 *
 * @package CoLabsFramework
 * @subpackage Template
 */

get_header();
?>
<?php colabs_content_before(); ?>
<div class="bg-main container">
	<div class="row">
		<div class="main columns col12">
			<?php colabs_main_before(); ?>
			<div class="content column col9  <?php colabs_post_class(); ?>">
				<?php query_posts('post_type=post&paged='.$paged);get_template_part( 'loop', 'archive' ); ?>
			</div><!-- .content -->
			<?php colabs_main_after(); ?>
			<?php get_sidebar('blog'); ?>

		</div><!-- .main -->
	</div><!-- .container -->
</div><!-- .bg-main -->
<?php colabs_content_after(); ?>

<?php get_footer(); ?>