<?php
/*
Template Name: Featured Product
*/
?>			

<?php get_header('shop');
global $colabs_posttype;
?>
<div class="bg-main container">
<div class="main row">
	<div id="content" class="column col12">
		
		<?php colabs_breadcrumbs();?>
		
		<?php 
			if($plugin=='wpsc'){
					$featured = get_option('sticky_products');
					$arg = array(
								'post__in' 			=> $featured,
								'post_type' 		=> $colabs_posttype,
								'paged' 		=> $paged
							 );
					query_posts($arg);		 
					?>
					<h2 class="entry-title"><?php the_title();?></h2>
					<div class="row product-list">
						<?php while (wpsc_have_products()) :  wpsc_the_product(); ?>
							<?php colabs_get_template_part( 'loop', 'product' );?>
						<?php endwhile;?>			
					</div>
					<?php	
				}else if($plugin=='jigoshop'){

				 $arg = array(
							'post_type' 		=> $colabs_posttype,
							'meta_key'			=> 'featured',
							'meta_value'		=> '1',
							'paged' 		=> $paged
						 );
					do_action('jigoshop_before_main_content');
					query_posts($arg);	 
					jigoshop_get_template_part( 'loop', 'shop' );	 
					do_action('jigoshop_after_main_content');
					
				}else if($plugin=='woo'){
					$arg = array(
							'post_type' 		=> $colabs_posttype,
							'meta_key'			=> '_featured',
							'meta_value'		=> 'yes',
							'paged' 		=> $paged
						 );
					do_action('woocommerce_before_main_content');	 
					query_posts($arg);	
					woocommerce_archive_product_content();	 
					do_action('woocommerce_after_main_content');
				}else {
					$arg = array(
							'post_type' 		=> $colabs_posttype,
							'paged' 		=> $paged
						 );
					query_posts($arg);		 
					?>
					<?php colabs_main_before(); ?>
					<div class="content column col9  <?php colabs_post_class(); ?>">
						<?php get_template_part( 'loop', 'archive' ); ?>
					</div><!-- .content -->
					<?php colabs_main_after(); ?>
					<?php get_sidebar('blog'); ?>
					<?php	 
				}
					
		?>
		
		<?php colabs_pagination();?><!-- .pagination -->
		
		
		
	</div><!-- #content -->
</div><!-- .main -->
</div>
<?php get_footer('shop'); ?>