<?php
/*
Template Name: Sitemap
*/
?>			

<?php get_header(); 
global $colabs_posttype,$colabs_taxonomy,$plugin;?>
<?php colabs_content_before(); ?>
<div class="bg-main container">
	<div class="row">
		<div class="main columns col12">
			
				<?php colabs_main_before(); ?>
				<div class="content column col9  <?php colabs_post_class(); ?>">
					<?php colabs_loop_before();?>
					<div class="entry">
					<h2 class="entry-title"><?php the_title();?></h2>                
					
					<div class="entry-content">
				
						<div class="entry page-list">
						  <h4><?php _e('Pages:');?></h4>
						  <ul class="block-list">
							<?php wp_list_pages('title_li='); ?>
						  </ul>
						</div>
						<div class="entry feed-list">
						  <h4><?php _e('RSS Feed:');?></h4>
						  <ul class="block-list">
							<li><a href="<?php bloginfo('rdf_url'); ?>" title="RDF/RSS 1.0 feed"><acronym title="Resource Description Framework">RDF</acronym>/<acronym title="Really Simple Syndication">RSS</acronym> 1.0 feed</a></li>
							<li><a href="<?php bloginfo('rss_url'); ?>" title="RSS 0.92 feed"><acronym title="Really Simple Syndication">RSS</acronym> 0.92 feed</a></li>
							<li><a href="<?php bloginfo('rss2_url'); ?>" title="RSS 2.0 feed"><acronym title="Really Simple Syndication">RSS</acronym> 2.0 feed</a></li>
							<li><a href="<?php bloginfo('atom_url'); ?>" title="Atom feed">Atom feed</a></li>
						  </ul>								
						</div>
						<div class="entry cat-list">
						  <h4><?php _e('Categories:');?></h4>
						  <ul class="block-list">
							<?php wp_list_categories('title_li=&hierarchical=0&show_count=1') ?>
						  </ul>
						</div>
						<div class="entry month-list">
						  <h4><?php _e('Monthly Archives');?></h4>
						  <ul class="block-list">
							<?php wp_get_archives('type=monthly'); ?>
						  </ul>
						</div>
						<div class="entry">
							<?php 
								$taxonomy     = $colabs_taxonomy;
								$orderby      = 'name'; 
								$show_count   = 1;      // 1 for yes, 0 for no
								$pad_counts   = 1;      // 1 for yes, 0 for no
								$hierarchical = 1;      // 1 for yes, 0 for no
								$title        = '';
										
								$args = array(
									'taxonomy'     => $taxonomy,
									'orderby'      => $orderby,
									'show_count'   => $show_count,
									'pad_counts'   => $pad_counts,
									'hierarchical' => $hierarchical,
									'title_li'     => $title
								);
							?>
							<h3><?php _e('Product Categories:');?></h3>
							<ul >
								<?php wp_list_categories( $args ); ?>
							</ul>
						</div>
					</div>
			
					</div>
					<?php colabs_loop_after();?>
				</div><!-- .content -->
				<?php colabs_main_after(); ?>
				<?php get_sidebar(); ?>
			
		</div><!-- .main -->
	</div><!-- .container -->
</div><!-- .bg-main -->
<?php colabs_content_after(); ?>

<?php get_footer(); ?>