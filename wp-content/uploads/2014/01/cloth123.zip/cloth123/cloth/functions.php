<?php
locate_template( 'includes/theme-options-layout.php', true );
locate_template( 'includes/theme-actions.php', true );
include( STYLESHEETPATH . '/includes/widgets/widget-colabs-product-search.php' );
include( STYLESHEETPATH . '/includes/widgets/widget-colabs-fbfriends.php' );

/*-----------------------------------------------------------------------------------*/
/* Register Menu */
/*-----------------------------------------------------------------------------------*/

if ( function_exists('register_nav_menus') ) {
    register_nav_menus( array(
        'main-menu' => __( 'Main Menu','colabsthemes' )
    ));    
}

if (!function_exists('colabs_nav_fallback')) {
function colabs_nav_fallback($div_id){ 
        wp_page_menu('&depth=0&title_li=&menu_class=navigation column col9 fr');
}}

if(!function_exists('colabs_page_menu')){
    function colabs_page_menu( $ulclass ){

    return preg_replace('/<ul>/', '<ul class="menu fr">', $ulclass, 1);

    }    
} 

/*-----------------------------------------------------------------------------------*/
/* CoLabs - Remove Page Template */
/*-----------------------------------------------------------------------------------*/
add_action('admin_head-post.php', 'colabs_remove_parent_templates');
add_action('admin_head-post-new.php', 'colabs_remove_parent_templates');
function colabs_remove_parent_templates() {
    colabs_remove_page_template(
        array('template-search.php', 'template-photoblog.php', 'template-magazine.php', 'template-business.php', 'template-portfolio.php')
    );
}

/*-----------------------------------------------------------------------------------*/
/* CoLabs - Footer Credit */
/*-----------------------------------------------------------------------------------*/
function colabs_credit(){
global $themename,$colabs_options;
if( $colabs_options['colabs_footer_credit'] != 'true' ){ ?>
           <?php _e('Copyright','colabsthemes') ?>" &copy; <?php echo date('Y'); ?> <a href="http://colorlabsproject.com/themes/<?php echo get_option('colabs_themename'); ?>/" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php echo get_option('colabs_themename'); ?></a> <?php _e('by','colabsthemes') ?>" <a href="http://colorlabsproject.com/" title="Colorlabs">ColorLabs & Company</a>. <?php _e('All rights reserved','colabsthemes') ?>".
<?php }else{ echo stripslashes( $colabs_options['colabs_footer_credit_txt'] ); } 
}

function colabs_product_excerpt($limit,$more) {
	if ($limit=='')$limit=35;
	$print_excerpt = '<p>';
	$content = get_the_content('');
	$content = strip_shortcodes( $content );
	$content = str_replace(']]>', ']]&gt;', $content);
	$content = strip_tags($content);	
	$excerpt = explode(' ',$content, $limit);
	array_pop($excerpt);
	$print_excerpt .= implode(" ",$excerpt).$more;
	$print_excerpt .= '</p>';
	echo $print_excerpt;
} 

/*-----------------------------------------------------------------------------------*/
/* CoLabs - Support Ecommerce Plugin */
/*-----------------------------------------------------------------------------------*/
function colabs_headercart() {
    if ( ! class_exists( 'Jigoshop_Widget_Cart' ) )
        return; 
	
	// quantity
	$qty = 0;
	if (sizeof(jigoshop_cart::$cart_contents)>0) : foreach (jigoshop_cart::$cart_contents as $item_id => $values) :
	
		$qty += $values['quantity'];
	
	endforeach; endif;
	echo '<a title="View your shopping cart" href="' . jigoshop_cart::get_cart_url() . '"><span>' . $qty . ' items</span></a> ';	
	
}
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if (is_plugin_active('woocommerce/woocommerce.php')){
	remove_action( 'woocommerce_pagination', 'woocommerce_pagination', 10 );
	remove_action( 'woocommerce_pagination', 'woocommerce_catalog_ordering', 20 );
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0);
	add_filter( 'woocommerce_sale_flash', 'colabs_woocommerce_sale_flash' ); 
	function colabs_woocommerce_sale_flash() { return '<span class="product-discount">'.__('On Sale!', 'colabsthemes').'</span>'; }
	/*---------------------------------------------------------------------------------*/
	/* Shop Filter */
	/*---------------------------------------------------------------------------------*/

	if (!function_exists('colabs_shop_filter')) {
		function colabs_shop_filter(){

			echo '<div class="row shop-filter">';
				woocommerce_catalog_ordering();
				
				/* Price Filter Widget */
				$Widget_Price = new WooCommerce_Widget_Price_Filter();	
				$args = array(
					'before_title' => '<h4 class="widget-title">',
					'after_title' => '</h4>',
					'before_widget' => '<div class="col4 widget_price_filter">',
					'after_widget' => '</div>'
				);
				
				$instance = array(
					'title' => ''		
				);
				$Widget_Price->widget( $args, $instance );
				
				/* Product Search Widget */
				$Product_Search = new CoLabs_Product_Search();	
				$args = array(
					'before_title' => '<h4 class="widget-title">',
					'after_title' => '</h4>',
					'before_widget' => '<div class="col4 widget_colabs_product_search">',
					'after_widget' => '</div>'
				);
				
				$instance = array(
					'title' => ''		
				);
				$Product_Search->widget( $args, $instance );
				echo '</div>';
		}
	}
	add_action('init', 'colabs_price_filter_init');

	/**
	 * Price filter Init
	 */
	function colabs_price_filter_init() {
		global $woocommerce;
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

			wp_register_script( 'wc-price-slider', $woocommerce->plugin_url() . '/assets/js/frontend/price-slider' . $suffix . '.js', array( 'jquery-ui-slider' ), '1.6', true );

			unset( $_SESSION['min_price'] );
			unset( $_SESSION['max_price'] );

			if ( isset( $_GET['min_price'] ) )
				$_SESSION['min_price'] = $_GET['min_price'];

			if ( isset( $_GET['max_price'] ) )
				$_SESSION['max_price'] = $_GET['max_price'];

			add_filter( 'loop_shop_post_in', 'woocommerce_price_filter' );
		
	}
}

if (is_plugin_active('jigoshop/jigoshop.php')){

	remove_action( 'jigoshop_before_main_content', 'jigoshop_breadcrumb', 20, 0);
	remove_action( 'jigoshop_before_main_content', 'jigoshop_output_content_wrapper'    , 10);
	remove_action( 'jigoshop_after_main_content' , 'jigoshop_output_content_wrapper_end', 10);
	remove_action( 'jigoshop_before_shop_loop_item_title', 'jigoshop_show_product_sale_flash', 10, 2);
	remove_action( 'jigoshop_before_single_product_summary_thumbnails', 'jigoshop_show_product_sale_flash', 10, 2);
	add_action( 'jigoshop_before_shop_loop_item_title', 'colabs_jigoshop_sale_flash', 10, 2);
	add_action( 'jigoshop_before_single_product_summary_thumbnails', 'colabs_jigoshop_sale_flash', 10, 2);
	function colabs_jigoshop_sale_flash($post, $_product) { if ($_product->is_on_sale()) echo '<span class="product-discount">'.__('On Sale!', 'jigoshop').'</span>'; }
} 
if (is_plugin_active('wp-e-commerce/wp-shopping-cart.php')){
	function colabs_the_product_price( $no_decimals = false, $only_normal_price = false, $product_id ) {
		global $wpsc_query, $wpsc_variations, $wpdb;
		if ($product_id=='')$product_id = get_the_ID();
		if ( ! empty( $wpsc_variations->first_variations ) ) {
			$from_text = apply_filters( 'wpsc_product_variation_text', ' from ' );
			$output = wpsc_product_variation_price_available( $product_id, __( " {$from_text} %s", 'wpsc' ), $only_normal_price );
		} else {
			$price = $full_price = get_post_meta( $product_id, '_wpsc_price', true );

			if ( ! $only_normal_price ) {
				$special_price = get_post_meta( $product_id, '_wpsc_special_price', true );

				if ( ( $full_price > $special_price ) && ( $special_price > 0 ) )
					$price = $special_price;
			}

			if ( $no_decimals == true )
				$price = array_shift( explode( ".", $price ) );

			$price = apply_filters( 'wpsc_do_convert_price', $price );
			$args = array(
				'display_as_html' => false,
				'display_decimal_point' => ! $no_decimals
			);
			$output = wpsc_currency_display( $price, $args );
		}
		return $output;
	}
}
// Front-end includes
if (!is_admin()) :

    get_template_part('includes/theme-login');
    get_template_part('includes/form/form');
    get_template_part('includes/form/form-process');


endif;

// contains the reCaptcha anti-spam system. Called on reg pages
function colabsthemes_recaptcha() {

    // process the reCaptcha request if it's been enabled
    if (get_option('colabs_captcha_enable') == 'true' && get_option('colabs_captcha_theme') && get_option('colabs_captcha_public_key')) :
?>
        <script type="text/javascript">
        // <![CDATA[
         var RecaptchaOptions = {
            custom_translations : {
                instructions_visual : "<?php _e('Type the two words:','colabsthemes') ?>",
                instructions_audio : "<?php _e('Type what you hear:','colabsthemes') ?>",
                play_again : "<?php _e('Play sound again','colabsthemes') ?>",
                cant_hear_this : "<?php _e('Download sound as MP3','colabsthemes') ?>",
                visual_challenge : "<?php _e('Visual challenge','colabsthemes') ?>",
                audio_challenge : "<?php _e('Audio challenge','colabsthemes') ?>",
                refresh_btn : "<?php _e('Get two new words','colabsthemes') ?>",
                help_btn : "<?php _e('Help','colabsthemes') ?>",
                incorrect_try_again : "<?php _e('Incorrect. Try again.','colabsthemes') ?>",
            },
            theme: "<?php echo get_option('colabs_captcha_theme') ?>",
            lang: "en",
            tabindex: 5
         };
        // ]]>
        </script>

        <p>
        <?php
        // let's call in the big boys. It's captcha time.
        require_once (TEMPLATEPATH . '/includes/lib/recaptchalib.php');
        echo recaptcha_get_html(get_option('colabs_captcha_public_key'));
        ?>
        </p>

<?php
    endif;  // end reCaptcha

}

/*---------------------------------------------------------------------------------*/
/* Deregister Default Widgets */
/*---------------------------------------------------------------------------------*/
if (!function_exists('colabs_deregister_widgets')) {
	function colabs_deregister_widgets(){
	    unregister_widget('WP_Widget_Search'); 
		if (is_plugin_active('jigoshop/jigoshop.php')){	
		unregister_widget('Jigoshop_Widget_Product_Search');	
		unregister_widget('Jigoshop_Widget_Cart');
		} 
		if (is_plugin_active('woocommerce/woocommerce.php')){	
		unregister_widget('WooCommerce_Widget_Product_Search');	
		unregister_widget('WooCommerce_Widget_Cart');		
		} 
		if (is_plugin_active('wp-e-commerce/wp-shopping-cart.php')){
		unregister_widget('WP_Widget_Shopping_Cart');
		}
	}
}
add_action('widgets_init', 'colabs_deregister_widgets');  






/*-----------------------------------------------------------------------------------*/
/*  Update cart wp e-commerce    */
/*-----------------------------------------------------------------------------------*/
function update_cart_count(){
    if ( ($_REQUEST['wpsc_ajax_action'] == 'add_to_cart') && $_REQUEST['ajax'] == TRUE ) {
        
        $total  = "<span>";
        $total .= sprintf( _n('%d item ', '%d items', wpsc_cart_item_count(), 'colabstheme'), wpsc_cart_item_count());
        $total .= "</span>";
        
        $output = '<h2>'. __('Cart', 'colabstheme') .'</h2>';
        $output .= '<ul>';
        while(wpsc_have_cart_items()): wpsc_the_cart_item();
          $output .= "<li>";
          $output .=    do_action ( "wpsc_before_cart_widget_item_name" );
          $output .=    "<a href='".  wpsc_cart_item_url() ."'>";
          $output .=      wpsc_cart_item_name();
          $output .=    "</a>";
          $output .=    do_action ( "wpsc_after_cart_widget_item_name" );
          $output .=    "<span class='quantity'>". wpsc_cart_item_quantity();
          $output .=    "<span class='amount'>". wpsc_cart_item_price() ."</span></span>";
          $output .=    "<form action='' method='post' class='adjustform'>";
          $output .=      "<input type='hidden' name='quantity' value='0' />";
          $output .=      "<input type='hidden' name='key' value='". wpsc_the_cart_item_key() ."'>";
          $output .=      "<input type='hidden' name='wpsc_update_quantity' value='true' />";
          $output .=      "<input class='remove_button' type='submit' value='&times;' />";
          $output .=    "</form>";
          $output .= "</li>";
        endwhile;
        $output .= '</ul>';

        $output .= "<p class='total'>";
        $output .=    "<strong>". __('Subtotal', 'colabsthemes') .":</strong>";
        $output .=    "<span class='amount'>". wpsc_cart_total_widget( false, false ,false ) ."</span></p>";
        $output .= "<p class='buttons'>";
        $output .=    "<a class='button checkout' href='". get_option('shopping_cart_url') ."'>". __('Checkout', 'wpsc') ."</a></p>";

        echo "jQuery('.arrow-cart .top-cart').html(\"$output\");";
        echo "jQuery('.arrow-cart > a').html(\"$total\");";
        exit;
    }
}
add_action( 'wpsc_alternate_cart_html', 'update_cart_count' );

/*-----------------------------------------------------------------------------------*/
/* WordPress Customizer */
/*-----------------------------------------------------------------------------------*/

// Remove previous customizer settings from Backbone
function remove_parent_customizer() {
  remove_action('customize_register', 'colabs_customize_register');
  //remove_action( 'customize_preview_init', 'colabs_customize_preview_js' );
}
add_action('init', 'remove_parent_customizer');

// Registering Customizer Settings
function colabs_children_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
	
  // Logo Settings
  // -------------
  $wp_customize->add_section( 'logo_settings', array(
    'title'    => __( 'Logo Settings', 'colabsthemes' ),
    'priority' => 21,
  ) );

  $wp_customize->add_setting( 'colabs_logo', array(
    'type'        => 'option',
    'capability'  => 'manage_options',
  ) );

  $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'colabs_logo', array(
    'label'    => __( 'Logo', 'colabsthemes' ),
    'section'  => 'logo_settings',
    'settings' => 'colabs_logo',
    'priority' => 1,
	'label'      => __('Upload a logo for your theme. Best image size in 100x42 px', 'colabsthemes')
  ) ) );
  
  // Main Layout
  $wp_customize->add_section( 'colabs_layout', array(
    'title'    => __( 'Layout', 'colabsthemes' ),
    'priority' => 22,
  ) );

  $wp_customize->add_setting( 'colabs_layout', array(
    'type'        => 'option',
    'default'     => 'two-col-left',
    'capability'  =>  'manage_options',
  ) );

  $wp_customize->add_control( 'colabs_layout', array(
    'section'    => 'colabs_layout',
    'type'       => 'radio',
    'choices'    => array(
      'two-col-left'  => __( 'Content on left', 'colabsthemes' ),
      'two-col-right' => __( 'Content on right', 'colabsthemes' ),
      'one-col'       => __( 'One-column, no sidebar', 'colabsthemes' )
    )
  ) );

  //Footer Layout
  //------------------
  $wp_customize->add_section( 'footer_layout_setting', array(
    'title'    => __( 'Footer Layout Setting', 'colabsthemes' ),
    'priority' => 24,
  ) );

  $wp_customize->add_setting( 'colabs_layout_footer_sidebars', array(
    'type'              => 'option',
    'default'           => get_option('colabs_layout_footer_sidebars'),
    'sanitize_callback' => 'sanitize_key',
  ) );

  $footlayouts = array(
    '0'  => __('No Footer Sidebar', 'colabsthemes'),
    '1' => __('One Footer Sidebar', 'colabsthemes'),
	'2' => __('Two Footer Sidebar', 'colabsthemes'),
	'3' => __('Three Footer Sidebar', 'colabsthemes'),
	'4' => __('Four Footer Sidebar', 'colabsthemes')
  );
  $wp_customize->add_control( 'footer_layout_setting', array(
    'section'    => 'footer_layout_setting',
    'type'       => 'radio',
    'settings'   => 'colabs_layout_footer_sidebars',
    'choices'    => $footlayouts,
	'label'      => __('Select how many footer widget areas you want to display.', 'colabsthemes')
  ) );
 
  // Frontpage
	$wp_customize->add_section( 'frontpage_setting', array(
		'title'    => __( 'Frontpage Setting', 'colabsthemes' ),
		'priority' => 50,
	) );
	
	$wp_customize->add_setting( 'colabs_headline_product', array(
		'type'              => 'option',
		'default'           => get_option('colabs_headline_product'),
		'capability' 		=> 'manage_options'
	) );
	
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	if (is_plugin_active('wp-e-commerce/wp-shopping-cart.php')) {
		$colabs_taxonomy='wpsc_product_category';
	}else if (is_plugin_active('jigoshop/jigoshop.php')){
		$colabs_taxonomy='product_cat';
	}else if (is_plugin_active('woocommerce/woocommerce.php')){
		$colabs_taxonomy='product_cat';	
	}else{
		$colabs_taxonomy='category';
	}
	$colabs_product_categories = array();  
	$colabs_product_categories_obj = get_categories('taxonomy='.$colabs_taxonomy.'&hide_empty=0');
	foreach ($colabs_product_categories_obj as $colabs_product_cat) {
		$colabs_product_categories[$colabs_product_cat->cat_ID] = $colabs_product_cat->cat_name;}
		
	$wp_customize->add_control( 'colabs_headline_product', array(
		'section'    => 'frontpage_setting',
		'type'       => 'select',
		'choices'    => $colabs_product_categories,
		'label'   => __( 'Headline Product Category', 'colabsthemes'  )
	) );
	
	//--------------------------------------------------------------------------------
	//New Arrivals Limit
	  
	$wp_customize->add_setting( 'colabs_new_arrivals_limit', array(
				'default'    => get_option('colabs_new_arrivals_limit'),
				'type'       => 'option',
				'capability' => 'manage_options',
			) );
			
	$wp_customize->add_control( 'colabs_new_arrivals_limit', array(
				'label'   => __( 'New Arrivals Limit', 'colabsthemes'  ),
				'section' => 'frontpage_setting'
			) );

	//--------------------------------------------------------------------------------
	//Featured Products Limit
	  
	$wp_customize->add_setting( 'colabs_featured_limit', array(
				'default'    => get_option('colabs_featured_limit'),
				'type'       => 'option',
				'capability' => 'manage_options',
			) );
			
	$wp_customize->add_control( 'colabs_featured_limit', array(
				'label'   => __( 'Featured Products Limit', 'colabsthemes'  ),
				'section' => 'frontpage_setting'
			) );		
			
	//--------------------------------------------------------------------------------
	//Latest Post Limit
	  
	$wp_customize->add_setting( 'colabs_latest_limit', array(
				'default'    => get_option('colabs_latest_limit'),
				'type'       => 'option',
				'capability' => 'manage_options',
			) );
			
	$wp_customize->add_control( 'colabs_latest_limit', array(
				'label'   => __( 'Latest Post Limit', 'colabsthemes'  ),
				'section' => 'frontpage_setting'
			) );		
}
add_action( 'customize_register', 'colabs_children_customize_register', 100 );

/**
 * Bind JS handlers to make Theme Customizer preview reload changes asynchronously.
 * Used with blogname and blogdescription.
 *
 */
function colabs_children_customize_preview_js() {
  wp_enqueue_script( 'colabs-customizer', get_stylesheet_directory_uri() . '/includes/js/theme-customizer.js', array( 'customize-preview' ), '20120620', true );
}
add_action( 'customize_preview_init', 'colabs_children_customize_preview_js' );
?>