<?php
if (!is_admin()) add_action( 'wp_print_scripts', 'colabsthemes_add_javascript' );

if (!function_exists('colabsthemes_add_javascript')) {

	function colabsthemes_add_javascript () {
        wp_enqueue_script('jquery');	

		wp_enqueue_script( 'sooperfish', trailingslashit( get_template_directory_uri() ) . 'includes/js/jquery.sooperfish.js', array('jquery') );
		wp_enqueue_script( 'flexslider', get_stylesheet_directory_uri() . '/includes/js/jquery.flexslider-min.js', array('jquery') );
		wp_enqueue_script( 'zero', get_stylesheet_directory_uri() . '/includes/js/zero.js', array('jquery') );
        
		if (is_plugin_active('woocommerce/woocommerce.php')){
		global $woocommerce;	
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		
		wp_register_script( 'wc-price-slider', $woocommerce->plugin_url() . '/assets/js/frontend/price-slider' . $suffix . '.js', array( 'jquery-ui' ), '1.6', true );
		}
		/* We add some JavaScript to pages with the comment form to support sites with threaded comments (when in use). */        
        	if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' );
        
	} /* // End colabsthemes_add_javascript() */
	
} /* // End IF Statement */

?>
