<?php

// Register widgetized areas

	function the_widgets_init() {
	    if ( !function_exists('register_sidebars') )
	        return;
	register_sidebar( array(
		'name' => __( 'Shop Sidebar', 'colabsthemes' ),
		'id' => 'primary',
		'description' => __( 'Normal full width Sidebar', 'colabsthemes' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => "</div>",
		'before_title' => '<h2 class="title-widget">',
		'after_title' => '</h2>',
	) );
    
	register_sidebar( array(
		'name' => __( 'Home Sidebar', 'colabsthemes' ),
		'id' => 'home',
		'description' => __( 'Just Display at home page', 'colabsthemes' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => "</div>",
		'before_title' => '<h2 class="title-widget">',
		'after_title' => '</h2>',
	) );
	
	register_sidebar( array(
		'name' => __( 'Blog Sidebar', 'colabsthemes' ),
		'id' => 'blog',
		'description' => __( 'Sidebar for blog page, single post, and archive', 'colabsthemes' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => "</div>",
		'before_title' => '<h2 class="title-widget">',
		'after_title' => '</h2>',
	) );
		// Footer widgetized area
		$total = get_option('colabs_layout_footer_sidebars');
		if (!$total)
			$total = 3;
		$i=0; while ($i < $total) : $i++;
			register_sidebar( array(
                'name' => 'Footer Widgets '.$i,
                'id' => 'footer-'.$i,
                'description' => __( 'Widgets area in footer', 'colabsthemes' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget' => '</div>',
                'before_title' => '<h2 class="title-widget">',
                'after_title' => '</h2>'
                ));
		endwhile;

    }

add_action( 'init', 'the_widgets_init' );


    
?>