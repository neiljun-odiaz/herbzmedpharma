<?php
    global $colabs_options;
	$colabs_options = get_option( 'colabs_options' );
	
/*------------------------------------------------------------------------------------

TABLE OF CONTENTS

- Theme Setup
- CoLabs Conditionals
- Add custom styling
- Add layout to body_class output
- Add layout to post_class output
- Add custom post_class output - colabs_post_class
- CoLabsSlider Setup
- CoLabsSlider Magazine template
- Navigation
- Post More
- Video Embed - backbone_get_embed
- Dynamic Image - backbone_get_image
- Single Post Author
- Yoast Breadcrumbs
- Single Post
- CoLabs Advertisement
- Share Button - backbone_single_share
- Optional Top Navigation (WP Menus)
- Footer Widgetized Areas
- Add customisable footer areas
- Add customisable post meta
- Add Post Thumbnail to Single posts on Archives
- Post Inside After
- Modify the default "comment" form field.
- Add theme default comment form fields.
- Add theme default comment form arguments.
- Activate shortcode compatibility in our new custom areas.
- colabs_content_templates_magazine()
- colabs_feedburner_link()
- Add video embed or image before post content in single - add_meta_single
- Add Portfolio Meta in single_portfolio - add_meta_portfolio
- Colabs Advanced Search Form - colabs_form_advanced_search

------------------------------------------------------------------------------------*/

add_action( 'colabs_head','colabs_custom_styling', 10 );						// Add custom styling
add_filter( 'body_class','colabs_layout_body_class', 10 );					// Add layout to body_class output
add_filter( 'post_class','colabs_layout_post_class', 10 );					// Add layout to post_class output
add_action( 'colabs_header_after','colabs_nav', 10 );							// Navigation
add_action( 'colabs_nav_inside','colabs_nav_subscribe', 10 );					// Subscribe links in navigation
add_action( 'colabs_head', 'colabs_conditionals', 10 );						// CoLabs Conditionals

add_action( 'wp_head', 'colabs_ads', 10 );								// Advertisement
add_action( 'colabs_post_inside_after', 'colabs_postnav', 11 );						// Single post navigation
add_action( 'wp_head', 'colabs_google_webfonts', 10 );						// Add Google Fonts output to HEAD			

if ( @$colabs_options['colabs_breadcrumbs_show'] == 'true' ) {
    add_filter('colabs_breadcrumbs_args','backbone_breadcrumbs_args');          //Breadcrumbs args
	add_action( 'colabs_loop_before', 'colabs_breadcrumbs', 10 );				// Breadcrumbs
} // End IF Statement

add_action( 'wp_head', 'colabs_author', 10 );					// Author Box
add_action( 'wp_head', 'colabs_single_action', 10 );			// Single Post - Related Posts
add_action( 'wp_head', 'backbone_single_share', 10 );			// Share Button

add_filter('wp_page_menu','colabs_page_menu');
/*-----------------------------------------------------------------------------------*/
/* Theme Setup */
/*-----------------------------------------------------------------------------------*/
/**
 * Theme Setup
 *
 * This is the general theme setup, where we add_theme_support(), create global variables
 * and setup default generic filters and actions to be used across our theme.
 *
 * @package CoLabsFramework
 * @subpackage Logic
 */
 
/**
 * Set the content width based on the theme's design and stylesheet.
 *
 * Used to set the width of images and content. Should be equal to the width the theme
 * is designed for, generally via the style.css stylesheet.
 */

if ( ! isset( $content_width ) ) $content_width = 640;

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support for post thumbnails.
 *
 * To override colabsthemes_setup() in a child theme, add your own colabsthemes_setup to your child theme's
 * functions.php file.
 *
 * @uses add_theme_support() To add support for post thumbnails and automatic feed links.
 * @uses add_editor_style() To style the visual editor.
 */

add_action( 'after_setup_theme', 'colabsthemes_setup' );

if ( ! function_exists( 'colabsthemes_setup' ) ) {
	function colabsthemes_setup () {
	
		// This theme styles the visual editor with editor-style.css to match the theme style.
		add_editor_style();
	
		// This theme uses post thumbnails
		add_theme_support( 'post-thumbnails' );
	
		// Add default posts and comments RSS feed links to head
		add_theme_support( 'automatic-feed-links' );
		
	} // End colabsthemes_setup()
} // End IF Statement

/*-----------------------------------------------------------------------------------*/
/* CoLabs Conditinals */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('colabs_conditionals')) {
	function colabs_conditionals() { 

        // Add CoLabs Custom Meta Post (Image/Embed)
        if( is_home() || is_archive() || is_singular() || is_search() ){
            
            if( is_page_template('template-photoblog.php') || is_tax('photoblog_category') ){
                
                add_action( 'colabs_post_inside_before', 'add_meta_single', 10 );     // Add Image or Video to Photoblog posts or archive
                
            }else{
                
                if( get_option('colabs_post_content') == 'excerpt' ) 
                    add_action( 'colabs_post_content_before', 'add_meta_single', 10 );     // Add Image or Video to Single posts
                
            }
            
        }

        global $post;
		$colabs_form_placement = get_post_meta($post->ID, 'colabs_form_placement', true);
        if(!isset($colabs_form_placement)){ $colabs_form_placement == 'before'; }
        
        if( is_page_template('template-search.php') ){

            add_action( 'colabs_post_content_'.$colabs_form_placement, 'colabs_form_advanced_search' );
            
        }elseif(is_search() && $_GET['bb_searchform_submit'] == 'bb_search_process' ){
            
            add_action( 'colabs_loop_before', 'colabs_form_advanced_search' );
            
        }
        
        if(is_search()) echo $colabs_form_placement;
        
        if( is_archive() ){
            
            add_action('colabs_loop_before', 'get_dynamictitles', 11); //Add Dynamic Titles after breadcrumbs
                
        }
        
        if( get_post_type() == 'portfolio' ){
            
            add_action( 'colabs_post_content_before', 'add_meta_portfolio', 11 );   // Add Custom Portfolio Meta
            
        }
        
        if( is_single() && get_post_type() != 'photoblog' ) add_action( 'colabs_post_inside_after', 'colabs_post_inside_after_default', 9 );    // Add Post Tag after post content
        
	}
}

/*-----------------------------------------------------------------------------------*/
/* // Get Dynamic Titles */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('get_dynamictitles')) {
function get_dynamictitles(){
    $args = array( 'before' => '<h1>', 'after' => '</h1>' );
    dynamictitles($args);
}}

/*-----------------------------------------------------------------------------------*/
/* // Add custom styling */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('colabs_custom_styling')) {
function colabs_custom_styling() {

	global $colabs_options;
	$output = '';
			
	// Logo
	if ( !$colabs_options['colabs_logo'] )
		$output .= '#logo .site-title, #logo .site-description { display:block; }' . "\n";

	// Styling options output in header
	if ( $colabs_options['colabs_layout_style_disable'] <> "true" ) :

		// Layout styling
		$bg = $colabs_options['colabs_layout_style_bg'];
		$bg_image = $colabs_options['colabs_layout_style_bg_image'];
		$bg_image_repeat = $colabs_options['colabs_layout_style_bg_image_repeat'];		
		$border_general = $colabs_options['colabs_layout_style_border'];
	
		$body = '';
		if ($bg)
			$body .= 'background-color:'.$bg.';';
		if ($bg_image)
			$body .= 'background-image:url('.$bg_image.');';
		if ($bg_image_repeat)
			$body .= 'background-repeat:'.$bg_image_repeat.';background-position:top center;';
	
		if ( $body != '' )
			$output .= 'body {'. $body . '}'. "\n";
	
		if ( $border_general )
			$output .= '#sidebar .widget, #sidebar-second .widget, #footer-widgets, 
						#footer, .entry-related, #page-top, .commentlist li, .commentlist .children,  
						.entry .entry-comment, .entry-comment-link, .entry-add-comment,
						.news-list, .news-list .entry-comment
						{border-color:'. $border_general . '}'. "\n";
			
	
		// General styling
		$link = $colabs_options['colabs_layout_link_color'];
		$hover = $colabs_options['colabs_layout_link_hover_color'];
		$button = $colabs_options['colabs_layout_button_color'];
		$fontbutton = $colabs_options['colabs_layout_font_button_color'];
	
		if ($link)
			$output .= 'a:link, a:visited {color:'.$link.'}' . "\n";
		if ($hover)
			$output .= 'a:hover, .post-more a:hover, .post-meta a:hover, .post p.tags a:hover {color:'.$hover.'}' . "\n";
		if ($button)
			$output .= '.button, .reply a, .widget_colabs_subscribe input[type="submit"], .form-submit input[type="submit"], #frmcontact .submit  {background:'.$button.'}' . "\n";
		if ($fontbutton)
			$output .= '.button, .reply a, .widget_colabs_subscribe input[type="submit"], .form-submit input[type="submit"], #frmcontact .submit  {color:'.$fontbutton.'}' . "\n";
			
		// Header styling		
		$header_bg = $colabs_options['colabs_layout_header_bg'];	
		$header_bg_image = $colabs_options['colabs_layout_header_bg_image'];			
		$header_bg_image_repeat = $colabs_options['colabs_layout_header_bg_image_repeat'];		
		$header_border = $colabs_options['colabs_layout_header_border'];
		$header_margin_top = $colabs_options['colabs_layout_header_margin_top'];			
		$header_margin_bottom = $colabs_options['colabs_layout_header_margin_bottom'];			
		$header_padding_top = $colabs_options['colabs_layout_header_padding_top'];			
		$header_padding_bottom = $colabs_options['colabs_layout_header_padding_bottom'];			
		$header_padding_left = $colabs_options['colabs_layout_header_padding_left'];			
		$header_padding_right = $colabs_options['colabs_layout_header_padding_right'];					
		$font_logo = $colabs_options['colabs_layout_font_logo'];	
		$font_desc = $colabs_options['colabs_layout_font_desc'];	

		$header_css = '';
		if ( $header_bg )
			$header_css .= 'background-color:'.$header_bg.';';	
		if ( $header_bg_image )
			$header_css .= 'background-image:url('.$header_bg_image.');';	
		if ( $header_bg_image_repeat )
			$header_css .= 'background-repeat:'.$header_bg_image_repeat.';background-position:top center;';
		if ( $header_margin_top <> '' || $header_margin_bottom <> '' )
			$header_css .= 'margin-top:'.$header_margin_top.'px;margin-bottom:'.$header_margin_bottom.'px;';	
		if ( $header_padding_top <> '' || $header_padding_bottom <> '' )
			$header_css .= 'padding-top:'.$header_padding_top.'px;padding-bottom:'.$header_padding_bottom.'px;';	
		if ( $header_border && $header_border['width'] >= 0)
			$header_css .= 'border:'.$header_border["width"].'px '.$header_border["style"].' '.$header_border["color"].';';
		if ( $header_border && $header_border['width'] > 0) {
			$width = get_option('colabs_layout_width') - $header_border['width']*2;
			//if ( $width > 0 ) 
				//$header_css .= 'width:'.$width.'px;';
		}
		if ( $header_css != '' )
			$output .= '#header {'. $header_css . '}'. "\n";
			
		if ( $header_padding_left <> '' )
			$output .= '#logo {padding-left:'.$header_padding_left.'px;}';
		if ( $header_padding_right <> '' )
			$output .= '#topad {padding-right:'.$header_padding_right.'px;}'. "\n";
		if ( $font_logo )
			$output .= '#logo .site-title a {' . colabs_generate_font_css( $font_logo ) . '}' . "\n";	
		if ( $font_desc )
			$output .= '#tagline {' . colabs_generate_font_css( $font_desc ) . '}' . "\n";	
		
		
		// Boxed styling
		$boxed = $colabs_options['colabs_layout_boxed'];
		$box_bg = $colabs_options['colabs_style_box_bg'];
		$box_margin_top = $colabs_options['colabs_box_margin_top'];
		$box_margin_bottom = $colabs_options['colabs_box_margin_bottom']; 
		$box_border_tb = $colabs_options['colabs_box_border_tb'];
		$box_border_lr = $colabs_options['colabs_box_border_lr'];
		$box_border_radius = $colabs_options['colabs_box_border_radius'];
		$box_shadow = $colabs_options['colabs_box_shadow'];
	
		$wrapper = '';
		if ($boxed == "true") {
			//$wrapper .= 'margin:0 auto;padding:0 0 20px 0;width:'.get_option('colabs_layout_width').';';
			if ( get_option('colabs_layout_width') == '940px' )
				$wrapper .= 'padding-left:20px; padding-right:20px;';
			else
				$wrapper .= 'padding-left:30px; padding-right:30px;';			
		}
		if ($boxed == "true" && $box_bg)
			$wrapper .= 'background-color:'.$box_bg.';';
		if ($boxed == "true" && ($box_margin_top || $box_margin_bottom) )
			$wrapper .= 'margin-top:'.$box_margin_top.'px;margin-bottom:'.$box_margin_bottom.'px;';
		if ($boxed == "true" && $box_border_tb["width"] > 0 )
			$wrapper .= 'border-top:'.$box_border_tb["width"].'px '.$box_border_tb["style"].' '.$box_border_tb["color"].';border-bottom:'.$box_border_tb["width"].'px '.$box_border_tb["style"].' '.$box_border_tb["color"].';';
		if ($boxed == "true" && $box_border_lr["width"] > 0 )
			$wrapper .= 'border-left:'.$box_border_lr["width"].'px '.$box_border_lr["style"].' '.$box_border_lr["color"].';border-right:'.$box_border_lr["width"].'px '.$box_border_lr["style"].' '.$box_border_lr["color"].';';
		if ( $boxed == "true" && $box_border_radius )
			$wrapper .= 'border-radius:'.$box_border_radius.';-moz-border-radius:'.$box_border_radius.';-webkit-border-radius:'.$box_border_radius.';';
		if ( $boxed == "true" && $box_shadow == "true" )
			$wrapper .= 'box-shadow: 0px 1px 5px rgba(0,0,0,.3);-moz-box-shadow: 0px 1px 5px rgba(0,0,0,.3);-webkit-box-shadow: 0px 1px 5px rgba(0,0,0,.3);';
	
		if ( $wrapper != '' )
			$output .= '#wrapper {'. $wrapper . '}'. "\n";
	
		// General Typography		
		$font_text = $colabs_options['colabs_layout_font_text'];
		$font_h1 = $colabs_options['colabs_layout_font_h1'];	
		$font_h2 = $colabs_options['colabs_layout_font_h2'];	
		$font_h3 = $colabs_options['colabs_layout_font_h3'];	
		$font_h4 = $colabs_options['colabs_layout_font_h4'];	
		$font_h5 = $colabs_options['colabs_layout_font_h5'];	
		$font_h6 = $colabs_options['colabs_layout_font_h6'];	
	
		if ( $font_text )
			$output .= 'body, p { ' . colabs_generate_font_css( $font_text, 1.5 ) . ' }' . "\n";
		if ( $font_h1 )
			$output .= 'h1 { ' . colabs_generate_font_css( $font_h1, 1.5 ) . ' }';	
		if ( $font_h2 )
			$output .= 'h2 { ' . colabs_generate_font_css( $font_h2, 1.5 ) . ' }';	
		if ( $font_h3 )
			$output .= 'h3 { ' . colabs_generate_font_css( $font_h3, 1.5 ) . ' }';	
		if ( $font_h4 )
			$output .= 'h4 { ' . colabs_generate_font_css( $font_h4, 1.5 ) . ' }';	
		if ( $font_h5 )
			$output .= 'h5 { ' . colabs_generate_font_css( $font_h5, 1.5 ) . ' }';	
		if ( $font_h6 )
			$output .= 'h6 { ' . colabs_generate_font_css( $font_h6, 1.5 ) . ' }' . "\n";	
	
		// Post Styling
		$font_post_title = $colabs_options['colabs_layout_font_post_title'];	
		$font_post_meta = $colabs_options['colabs_layout_font_post_meta'];	
		$font_post_text = $colabs_options['colabs_layout_font_post_text'];	
		$font_post_more = $colabs_options['colabs_layout_font_post_more'];	
		$post_more_border_top = $colabs_options['colabs_layout_post_more_border_top'];	
		$post_more_border_bottom = $colabs_options['colabs_layout_post_more_border_bottom'];	
		$post_comments_bg = $colabs_options['colabs_layout_post_comments_bg'];	
		$post_comments_bg_odd = $colabs_options['colabs_layout_post_comments_bg_odd'];
		$post_author_border_top = $colabs_options['colabs_layout_post_author_border_top'];	
		$post_author_border_bottom = $colabs_options['colabs_layout_post_author_border_bottom'];	
		$post_author_bg = $colabs_options['colabs_layout_post_author_bg'];	
		
		if ( $font_post_title )
			$output .= '.entry-title {'.colabs_generate_font_css( $font_post_title, 1.2 ).'}' . "\n";	
		if ( $font_post_meta )
			$output .= '.post-meta .entry-info { ' . colabs_generate_font_css( $font_post_meta, 1.5 ) . ' }' . "\n";	
		if ( $font_post_text )
			$output .= '.entry, .entry p{ ' . colabs_generate_font_css( $font_post_text, 1.5 ) . ' }' . "\n";	
		$post_more_border = '';
		if ( $font_post_more )
			$post_more_border .= 'font:'.$font_post_more["style"].' '.$font_post_more["size"].$font_post_more["unit"].'/1.5em '.stripslashes($font_post_more["face"]).';color:'.$font_post_more["color"].';';	
		if ( $post_more_border_top )
			$post_more_border .= 'border-top:'.$post_more_border_top["width"].'px '.$post_more_border_top["style"].' '.$post_more_border_top["color"].';';	
		if ( $post_more_border_bottom )
			$post_more_border .= 'border-bottom:'.$post_more_border_bottom["width"].'px '.$post_more_border_bottom["style"].' '.$post_more_border_bottom["color"].';';	
		if ( $post_more_border )
		$output .= '.post-more {'.$post_more_border .'}' . "\n";	
	
		if ( $post_comments_bg )
			$output .= '#comments .comment.thread-even {background-color:'.$post_comments_bg.';}' . "\n";
			
		if ( $post_comments_bg_odd )
			$output .= '#comments .comment.thread-odd {background-color:'.$post_comments_bg_odd.';}' . "\n";	

		$post_author = '';
		if ( $post_author_border_top )
			$post_author .= 'border-top:'.$post_author_border_top["width"].'px '.$post_author_border_top["style"].' '.$post_author_border_top["color"].';';	
		if ( $post_author_border_bottom )
			$post_author .= 'border-bottom:'.$post_author_border_bottom["width"].'px '.$post_author_border_bottom["style"].' '.$post_author_border_bottom["color"].';';		
		if ( $post_author_bg )
			$post_author .= 'background-color:'.$post_author_bg;
	
		if ( $post_author )
			$output .= '.entry-author {'.$post_author .'}' . "\n";	
	
		if ( $post_comments_bg )
			$output .= '#comments .comment.thread-even {background-color:'.$post_comments_bg.';}' . "\n";
		
		// Page Nav Styling	
		$pagenav_font = $colabs_options['colabs_layout_pagenav_font'];	
		$pagenav_bg = $colabs_options['colabs_layout_pagenav_bg'];	
		$pagenav_border_top = $colabs_options['colabs_layout_pagenav_border_top'];	
		$pagenav_border_bottom = $colabs_options['colabs_layout_pagenav_border_bottom'];	
	
		$pagenav_css = '';
		if ( $pagenav_bg )
			$pagenav_css .= 'background-color:'.$pagenav_bg.';';	
		if ( $pagenav_border_top && $pagenav_border_top["width"] > 0 )
			$pagenav_css .= 'border-top:'.$pagenav_border_top["width"].'px '.$pagenav_border_top["style"].' '.$pagenav_border_top["color"].';';	
		if ( $pagenav_border_bottom && $pagenav_border_bottom["width"] > 0 )
			$pagenav_css .= 'border-bottom:'.$pagenav_border_bottom["width"].'px '.$pagenav_border_bottom["style"].' '.$pagenav_border_bottom["color"].';';	
		if ( $pagenav_css != '' )
			$output .= '.colabs-pagination a, .colabs-pagintaion span, #page a {'. $pagenav_css . ' }'. "\n";
		if ( $pagenav_font ) {
			$output .= '#page a,.pagination span, .pagination a { ' . colabs_generate_font_css( $pagenav_font ) . ' }' . "\n";	
			$output .= '#page a,.pagination span, .pagination a {color:'.$pagenav_font["color"].'!important}' . "\n";	
		}
		// Widget Styling
		$widget_font_title = $colabs_options['colabs_layout_widget_font_title'];	
		$widget_font_text = $colabs_options['colabs_layout_widget_font_text'];	
		//$widget_padding_tb = $colabs_options['colabs_widget_padding_tb'];
		//$widget_padding_lr = $colabs_options['colabs_widget_padding_lr'];
		//$widget_bg = $colabs_options['colabs_widget_bg'];
		$widget_border = $colabs_options['colabs_layout_widget_border'];
		$widget_title_border = $colabs_options['colabs_layout_widget_title_border'];
		$widget_border_radius = $colabs_options['colabs_layout_widget_border_radius'];
	
		$h3_css = '';
		if ( $widget_font_title )
			$h3_css .= 'font:'.$widget_font_title["style"].' '.$widget_font_title["size"].$widget_font_title["unit"].'/1.5em '.stripslashes($widget_font_title["face"]).';color:'.$widget_font_title["color"].';';	
		if ( $widget_title_border )
			$h3_css .= 'border-bottom:'.$widget_title_border["width"].'px '.$widget_title_border["style"].' '.$widget_title_border["color"].';';	
		if ( isset( $widget_title_border["width"] ) AND $widget_title_border["width"] == 0 )
			$h3_css .= 'margin-bottom:0;';
		
		if ( $h3_css != '' )
			$output .= '.widget h3, #footer-widgets .widget h3 {'. $h3_css . '}'. "\n";
		
		
		
		if ( $widget_font_text )
			$output .= '.widget  { ' . colabs_generate_font_css( $widget_font_text, 1.5 ) . ' }' . "\n";	
	
		$widget_css = '';
		if ( $widget_font_text )
			$widget_css .= 'font:'.$widget_font_text["style"].' '.$widget_font_text["size"].$widget_font_text["unit"].'/1.5em '.stripslashes($widget_font_text["face"]).';color:'.$widget_font_text["color"].';';	
		//if ( $widget_padding_tb || $widget_padding_lr )
		//	$widget_css .= 'padding:'.$widget_padding_tb.'px '.$widget_padding_lr.'px;';	
		//if ( $widget_bg )
		//	$widget_css .= 'background-color:'.$widget_bg.';';	
		if ( $widget_border["width"] >= 0 )
			$widget_css .= 'border:'.$widget_border["width"].'px '.$widget_border["style"].' '.$widget_border["color"].';';	
		if ( $widget_border_radius )
			$widget_css .= 'border-radius:'.$widget_border_radius.';-moz-border-radius:'.$widget_border_radius.';-webkit-border-radius:'.$widget_border_radius.';';	
	
		if ( $widget_css != '' )
			$output .= '#sidebar .widget, #sidebar-second .widget, #footer-widgets .widget {'. $widget_css . '}'. "\n";

		if ( $widget_border["width"] >= 0 )
			$output .= '#tabs {border:'.$widget_border["width"].'px '.$widget_border["style"].' '.$widget_border["color"].';}'. "\n";

		// Tabs Widget
		$widget_tabs_bg = $colabs_options['colabs_layout_widget_tabs_bg'];	
		$widget_tabs_bg_inside = $colabs_options['colabs_layout_widget_tabs_bg_inside'];	
		$widget_tabs_font = $colabs_options['colabs_layout_widget_tabs_font'];	
		$widget_tabs_font_meta = $colabs_options['colabs_layout_widget_tabs_font_meta'];	
		
		if ( $widget_tabs_bg )
			$output .= '#tabs {background-color:'.$widget_tabs_bg.';}'. "\n";
		if ( $widget_tabs_bg_inside )
			$output .= '#tabs .inside, #tabs ul.colabsTabs li a.selected, #tabs ul.colabsTabs li a:hover {background-color:'.$widget_tabs_bg_inside.';}'. "\n";	
		if ( $widget_tabs_font )
			$output .= '#tabs .inside li a { ' . colabs_generate_font_css( $widget_tabs_font, 1.5 ) . ' }'. "\n";	
		if ( $widget_tabs_font_meta )
			$output .= '#tabs .inside li span.meta, #tabs ul.colabsTabs li a { ' . colabs_generate_font_css( $widget_tabs_font_meta, 1.5 ) . ' }'. "\n";	
	
		//Navigation
		$nav_bg = $colabs_options['colabs_layout_nav_bg'];	
		$nav_font = $colabs_options['colabs_layout_nav_font'];	
		$nav_hover = $colabs_options['colabs_layout_nav_hover'];
		$nav_currentitem = $colabs_options['colabs_layout_nav_currentitem'];	
		$nav_border_top = $colabs_options['colabs_layout_nav_border_top'];
		$nav_border_bot = $colabs_options['colabs_layout_nav_border_bot'];
		$nav_border_lr = $colabs_options['colabs_layout_nav_border_lr'];
		$nav_border_radius = $colabs_options['colabs_layout_nav_border_radius'];

		
		
		if ( $nav_font )
			$output .= '.topmenu .menu { ' . colabs_generate_font_css( $nav_font ) . ' }' . "\n";	
		if ( $nav_hover )
			$output .= '.topmenu .menu a:hover {background-color:'.$nav_hover.'}' . "\n";
	
		// If we have a hover colour and don't have a current item colour, we use the hover colour as current item colour.
		if ( $nav_currentitem == '' && $nav_hover != '' ) { $nav_currentitem = $nav_hover; }
	
		if ( $nav_currentitem ) {
			$output .= '.topmenu .current-menu-item a { background-color:' . $nav_currentitem . '; }' . "\n";
		}
	
		$navigation_css = '';
		if ( $nav_bg )
			$navigation_css .= 'background-color:'.$nav_bg.';';
		if ( $nav_border_top && $nav_border_top["width"] >= 0 )
			$navigation_css .= 'border-top:'.$nav_border_top["width"].'px '.$nav_border_top["style"].' '.$nav_border_top["color"].';border-bottom:'.$nav_border_bot["width"].'px '.$nav_border_bot["style"].' '.$nav_border_bot["color"].';border-left:'.$nav_border_lr["width"].'px '.$nav_border_lr["style"].' '.$nav_border_lr["color"].';border-right:'.$nav_border_lr["width"].'px '.$nav_border_lr["style"].' '.$nav_border_lr["color"].';';
		if ( $nav_border_radius )
			$navigation_css .= 'border-radius:'.$nav_border_radius.'; -moz-border-radius:'.$nav_border_radius.'; -webkit-border-radius:'.$nav_border_radius.';';	

		if ( $navigation_css != '' )
			$output .= '.topmenu .menu {'. $navigation_css . '}'. "\n";
			
		
			
	
		// Footer 
		$footer_font = $colabs_options['colabs_layout_footer_font'];	
		$footer_bg = $colabs_options['colabs_layout_footer_bg'];	
		$footer_border_top = $colabs_options['colabs_layout_footer_border_top'];	
		$footer_border_bottom = $colabs_options['colabs_layout_footer_border_bottom'];	
		$footer_border_lr = $colabs_options['colabs_layout_footer_border_lr'];	
		$footer_border_radius = $colabs_options['colabs_layout_footer_border_radius'];	
		$footer_padding_left = $colabs_options['colabs_layout_footer_padding_left'];	
		$footer_padding_right = $colabs_options['colabs_layout_footer_padding_right'];	
		
		if ( $footer_font )
			$output .= '#footer, #footer p { ' . colabs_generate_font_css( $footer_font ) . ' }' . "\n";	
		$footer_css = '';
		if ( $footer_bg )
			$footer_css .= 'background-color:'.$footer_bg.';';	
		if ( $footer_border_top )
			$footer_css .= 'border-top:'.$footer_border_top["width"].'px '.$footer_border_top["style"].' '.$footer_border_top["color"].';';	
		if ( $footer_border_bottom )
			$footer_css .= 'border-bottom:'.$footer_border_bottom["width"].'px '.$footer_border_bottom["style"].' '.$footer_border_bottom["color"].';';	
		if ( $footer_border_lr )
			$footer_css .= 'border-left:'.$footer_border_lr["width"].'px '.$footer_border_lr["style"].' '.$footer_border_lr["color"].';border-right:'.$footer_border_lr["width"].'px '.$footer_border_lr["style"].' '.$footer_border_lr["color"].';';	
		if ( $footer_border_radius )
			$footer_css .= 'border-radius:'.$footer_border_radius.'; -moz-border-radius:'.$footer_border_radius.'; -webkit-border-radius:'.$footer_border_radius.';';	

		if ( $footer_css != '' )
			$output .= '#footer {'. $footer_css . '}' . "\n";
			
		if ( $footer_padding_left <> '' )
			$output .= '#footer {padding-left:'.$footer_padding_left.'px;}';
		if ( $footer_padding_right <> '' )
			$output .= '#footer {padding-right:'.$footer_padding_right.'px;}'. "\n";	
			
		// Magazine Template
		$slider_magazine_font_title = $colabs_options['colabs_slider_magazine_font_title'];	
		$slider_magazine_font_excerpt = $colabs_options['colabs_slider_magazine_font_excerpt'];	
		
		if ( $slider_magazine_font_title )
			$output .= '.magazine #loopedSlider .content h2.title a { ' . colabs_generate_font_css( $slider_magazine_font_title ) . ' }'. "\n";	
		if ( $slider_magazine_font_excerpt )
			$output .= '.magazine #loopedSlider .content .excerpt p { ' . colabs_generate_font_css( $slider_magazine_font_excerpt, 1.5 ) . ' }'. "\n";	

		// Business Template
		$slider_biz_font_title = $colabs_options['colabs_slider_biz_font_title'];	
		$slider_biz_font_excerpt = $colabs_options['colabs_slider_biz_font_excerpt'];	

		if ( $slider_biz_font_title )
			$output .= '.business #loopedSlider .content h2.title a { ' . colabs_generate_font_css( $slider_biz_font_title ) . ' }'. "\n";	
		if ( $slider_biz_font_excerpt )
			$output .= '.business #loopedSlider .content p { ' . colabs_generate_font_css( $slider_biz_font_excerpt, 1.5 ) . ' }'. "\n";	
		
		// Archive Header
		/* $colabs_archive_header_font = $colabs_options['colabs_archive_header_font'];	
		if ( $colabs_archive_header_font )
			$output .= '.archive_header { ' . colabs_generate_font_css( $colabs_archive_header_font ) . 'border-bottom:'.$colabs_options['colabs_archive_header_border_bottom']["width"].'px '.$colabs_options['colabs_archive_header_border_bottom']["style"].' '.$colabs_options['colabs_archive_header_border_bottom']["color"].';}'. "\n";	
		if ( $colabs_options['colabs_archive_header_disable_rss'] == "true" )
			$output .= '.archive_header .catrss { display:none; }' . "\n"; */
			
	endif;
	
	// Output styles
	if (isset($output)) {
		$output = "\n<!-- CoLabs Custom Styling -->\n<style type=\"text/css\">\n" . $output  . "\n" . "</style>\n<!-- /CoLabs Custom Styling -->\n\n";
		echo $output;
	}
		
} 
}

// Returns proper font css output
if (!function_exists( 'colabs_generate_font_css')) {
	function colabs_generate_font_css($option, $em = '1') {

		// Google Fonts
		global $google_fonts;

		// check if font name has spaces
		if ( strpos( $option[ 'face' ], ' ' ) ) {
			
			// test if font face is a Google font
			foreach ( $google_fonts as $fonts ) {
				
				// Add single quotation marks to font name
				if ( $option[ 'face' ] == $fonts[ 'name' ] )
					$option[ 'face' ] = "'" . $option[ 'face' ] . "', arial, serif";
			}
		
		} // ENDIF
		
		return 'font:'.$option["style"].' '.$option["size"].$option["unit"].'/'.$em.'em '.stripslashes($option["face"]).';color:'.$option["color"].';';
	}
}


/*-----------------------------------------------------------------------------------*/
/* Add layout to body_class output */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'colabs_layout_body_class' ) ) {
	function colabs_layout_body_class( $classes ) {
	
		$layout = '';
		// Set main layout
		if ( is_singular() ) {
			global $post;
			$layout = get_post_meta($post->ID, 'layout', true); }

		// Cater for custom magazine layout option.
		if ( is_page_template('template-magazine.php') ) {
			$magazine_layout = get_option( 'colabs_magazine_layout' );
			if ( $magazine_layout != '' ) { $layout = $magazine_layout; }
		}

		// Cater for custom photoblog layout option.
		if ( is_page_template('template-photoblog.php') || is_tax('photoblog_category') || get_post_type() == 'photoblog' ) {
			$photoblog_layout = 'one-col';
			if ( $photoblog_layout != '' ) { $layout = $photoblog_layout; }
		}
        
        //set $colabs_option
        if ( $layout != '' ) {
			global $colabs_options;
            $colabs_options['colabs_layout'] = $layout; } else {
                $layout = get_option( 'colabs_layout' );
				if ( $layout == '' ) $layout = "two-col-left";
            }
                
		// Specify site width
		$width = get_option( 'colabs_layout_width' );
		if ( $width == '760px' ) 
			$width = "-760";
		elseif ( $width == '960px' ) 
			$width = "-960";
		elseif ( $width == '880px' ) 
			$width = "-880";
		elseif ( $width == '980px' ) 
			$width = "-980";
		elseif ( $width == '1200px' ) 
			$width = "-1200";
		else 
			$width = "-940";
		
		// Add classes to body_class() output 
		$classes[] = $layout;
		$classes[] = 'width' . $width;
		$classes[] = $layout . $width;
        
		return apply_filters('colabs_layout_body_class', $classes);
	}
}


/*-----------------------------------------------------------------------------------*/
/* Add layout to post_class output */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'colabs_layout_post_class' ) ) {
	function colabs_layout_post_class( $classes ) {
	
		$layout = '';
		// Set main layout
		if ( is_singular() ) {
			global $post;
			$layout = get_post_meta($post->ID, 'layout', true);
		}
        
		// Cater for custom magazine layout option.
		if ( is_page_template('template-magazine.php') ) {
			$magazine_layout = get_option( 'colabs_magazine_layout' );
			if ( $magazine_layout != '' ) { $layout = $magazine_layout; }
		}
        
		// Cater for custom photoblog layout option.
		if ( is_page_template('template-photoblog.php') || is_tax('photoblog_category') || get_post_type() == 'photoblog' ) {
			$photoblog_layout = 'one-col';
			if ( $photoblog_layout != '' ) { $layout = $photoblog_layout; }
		}

        //set $colabs_option
        if ( $layout != '' ) {
			global $colabs_options;
            $colabs_options['colabs_layout'] = $layout; 
        } else { 
            if ( is_page_template('template-search.php') ) {
                $layout = "two-col-left";
            }else{
                $layout = get_option( 'colabs_layout' );
                if ( $layout == '' ) $layout = "two-col-left";
            }
        }
        
        if( $layout == 'three-col-left' || $layout =='three-col-right' || $layout =='three-col-middle' ){ $col='col5'; }else
        if( $layout == 'two-col-left' || $layout =='two-col-right' ){ $col='col8'; }else
        if( $layout == 'one-col' ){ $col='col12'; }
	
		// Add classes to post_class() output
        $classes[] = $layout;
		$classes[] = $col;
        
        return apply_filters('colabs_layout_post_class', $classes);
	}
}

/*-----------------------------------------------------------------------------------*/
/* Add custom post_class output - colabs_post_class */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'colabs_post_class' ) ) {
	function colabs_post_class( $classes = array() ) {
        global $post, $colabs_options;
        
        if ( empty($post) ){
            $classes[] = 'no-post';
            echo 'class="' . join( ' ', colabs_layout_post_class( $classes ) ) . '"';            
        }else{
            post_class( $classes );
        }
        
    }
}
/*-----------------------------------------------------------------------------------*/
/* CoLabs Slider Setup */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('colabs_slider')) {
	function colabs_slider( $load_slider_js = false ) {
		global $colabs_options;
		
		$load_slider_js = false;
		
		if ( ( is_page_template('template-business.php') && $colabs_options['colabs_slider_biz'] == "true" ) || 
			 ( is_page_template('template-magazine.php') && $colabs_options['colabs_slider_magazine'] == "true" ) ) { $load_slider_js = true; }
			 
		// Allow child themes/plugins to load the slider JavaScript when they need it.
		$load_slider_js = apply_filters( 'colabs_load_slider_js', $load_slider_js );
		
		if ( $load_slider_js != false ) {
		
		// Default slider settings. 
		$defaults = array(
							'autoStart' => 0, 
							'autoHeight' => 'false', 
							'hoverPause' => 'false',
							'containerClick' => 'false', 
							'slideSpeed' => 600, 
							'canAutoStart' => 'false', 
							'next' => 'next', 
							'prev' => 'previous', 
							'container' => 'slides', 
							'generatePagination' => 'false', 
							'crossfade' => 'true', 
							'fadeSpeed' => 600, 
							'effect' => 'slide'
						 );
		
		// Dynamic settings from the "Theme Options" screen.				 
		$args = array();
		
		if ( $colabs_options['colabs_slider_pagination'] == 'true' ) { $args['generatePagination'] = 'true'; }
		if ( $colabs_options['colabs_slider_effect'] != '' ) { $args['effect'] = $colabs_options['colabs_slider_effect']; }
		if ( $colabs_options['colabs_slider_autoheight'] == 'true' ) { $args['autoHeight'] = 'true'; }
		if ( $colabs_options['colabs_slider_hover'] == 'true' ) { $args['hoverPause'] = 'true'; }
		if ( $colabs_options['colabs_slider_containerclick'] == 'true' ) { $args['containerClick'] = 'true'; }
		if ( $colabs_options['colabs_slider_speed'] == 'true' ) { $args['slideSpeed'] = $colabs_options['colabs_slider_speed'] * 1000; }
		if ( $colabs_options['colabs_slider_speed'] == 'true' ) { $args['fadeSpeed'] = $colabs_options['colabs_slider_speed'] * 1000; }
		if ( $colabs_options['colabs_slider_auto'] == 'true' ) {
			$args['canAutoStart'] = 'true';
			$args['autoStart'] = $colabs_options['colabs_slider_interval'] * 1000;
		}
		
		// Merge the arguments with defaults.
		$args = wp_parse_args( $args, $defaults );
		
		// Allow child themes/plugins to filter these arguments.
		$args = apply_filters( 'colabs_slider_args', $args );
		
	?>	
	<!-- CoLabs Slider Setup -->
	<script type="text/javascript">
	jQuery(window).load(function(){
	    jQuery( '#loopedSlider' ).slides({
			preload: true,
			preloadImage: '<?php echo get_template_directory_uri(); ?>/images/loading.png',
	        play: <?php echo $args['autoStart']; ?>, 
	        <?php if ( $args['effect'] == 'fade' ) { ?>
	         fadeSpeed: <?php echo $args['fadeSpeed']; ?>, 
	        <?php } else { ?>
	        slideSpeed: <?php echo $args['slideSpeed']; ?>, 
	        <?php } ?>
	        autoHeight: <?php echo $args['autoHeight']; ?>,
	        hoverPause: <?php echo $args['hoverPause']; ?>,
	        bigTarget: <?php echo $args['containerClick']; ?>, 
	        next: '<?php echo $args['next']; ?>', 
	        prev: '<?php echo $args['prev']; ?>', 
	        container: '<?php echo $args['container']; ?>', 
	        effect: '<?php echo $args['effect']; ?>', 
	        crossfade: true, 
	        generatePagination: <?php echo $args['generatePagination']; ?>
	    });
	    
	    jQuery( '#loopedSlider .pagination' ).wrap( '<div class="pagination-wrap" />' );
	});
	</script>
	<?php if ( ( isset( $containerClick ) ) && ( $containerClick == "true" ) ) { ?>
	<style type="text/css">#loopedSlider .container { cursor:pointer; }</style>
	<?php } ?>
	<!-- /CoLabs Slider Setup -->
	<?php
		}
	}
}
/*-----------------------------------------------------------------------------------*/
/* CoLabs Slider Magazine */
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'backbone_get_layout' ) ){
function backbone_get_layout( $layout = null, $layout_width = null ){
    
global $colabs_options;
if( $layout == '' )$layout = $colabs_options['colabs_layout'];
if( $layout_width == '' )$layout_width = get_option( 'colabs_layout_width' );
$return = array();

		if ( $layout == "one-col" ) {
	
			if ( $layout_width == '980px' ) { 
				$width = "978";
				$height = '613';
			} elseif ( $layout_width == '960px' ) {
				$width = "960";
				$height = '600';
			} elseif ( $layout_width == '880px' ) {
				$width = "880";
				$height = '550';
			} elseif ( $layout_width == '760px' ) {
				$width = "760";
				$height = '475';
			} elseif ( $layout_width == '1200px' ) {
				$width = "1200";
				$height = '750';
			} else {
				$width = "940";
				$height = '588';
			}
	
		} elseif ( $layout == "two-col-left" || $layout == "two-col-right" || $layout == "two-col-middle" ) {
	
			if ( $layout_width == '980px' ) { 
				$width = "642";
				$height = "365";
			} elseif ( $layout_width == '960px' ) {
				$width = "630";
				$height = "354";
			} elseif ( $layout_width == '880px' ) {
				$width = "550";
				$height = "309";
			} elseif ( $layout_width == '760px' ) {
				$width = "480";
				$height = "270";
			} elseif ( $layout_width == '1200px' ) {
				$width = "800";
				$height = "450";
			} else {
				$width = "610";
			}
	
		} elseif ( $layout == "three-col-left" || $layout == "three-col-right" || $layout == "three-col-middle" ) {
	
			if ( $layout_width == '980px' ) { 
				$width = "390";
				$height = "270";
			} elseif ( $layout_width == '960px' ) {
				$width = "460";
				$height = "259";
			} elseif ( $layout_width == '880px' ) {
				$width = "420";
				$height = "236";
			} elseif ( $layout_width == '760px' ) {
				$width = "350";
				$height = "197";
			} elseif ( $layout_width == '1200px' ) {
				$width = "680";
				$height = "380";
			} else {
				$width = "440";
				$height = "247";
			}
	
		}

    $return['width'] = $width;
    $return['height'] = $height;
    
    return $return;
}}
	
/*-----------------------------------------------------------------------------------*/
/* CoLabs Slider Magazine */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('colabs_slider_magazine')) {
	function colabs_slider_magazine( $args = null ) {
		
		global $colabs_options, $wp_query;
		
		// This is where our output will be added.
		$html = '';
		
		// Default slider settings. 
		$defaults = array(
							'id' => 'loopedSlider', 
							'echo' => true, 
							'excerpt_length' => '15', 
							'pagination' => false, 
							'width' => '980', 
							'height' => '350', 
							'order' => 'ASC', 
							'posts_per_page' => '5'
						 );
	
		// Setup width of slider and images
		$width = "650";
		$slider_width = '642';
        $slider_height = '320';
        
		$layout = $colabs_options['colabs_magazine_layout'];
		if ( !$layout['colabs_magazine_layout'] ) $layout = get_option( 'colabs_magazine_layout' ); 
		$layout_width = get_option( 'colabs_layout_width' );
        
        //get dynamic layout
        $layout_get = backbone_get_layout( $layout, $layout_width );
        $width = $layout_get['width'];
        $height = $layout_get['height'];
	
		// Setup slider tags array
		$slider_tags = explode(',',$colabs_options['colabs_slider_magazine_tags']); // Tags to be shown
		foreach ($slider_tags as $tags){ 
			$tag = get_term_by( 'name', trim($tags), 'post_tag', 'ARRAY_A' );
			if ( $tag['term_id'] > 0 )
				$tag_array[] = $tag['term_id'];
		}
		if ( empty($tag_array) ) {
			echo '<p class="note">Please setup Featured Slider Tag(s) in your options panel. You must setup tags that are used on active posts.</p>';
			return;
		}
			
		// Setup the slider CSS class.
		$slider_css = '';
		
		if ( @$colabs_options['colabs_slider_pagination'] == 'true' ) {
			$slider_css = ' class="has-pagination"';
		}
		
		// Setup height & width of slider.
		$height = $colabs_options['colabs_slider_magazine_height'];
		if ( $height != '' ) { 
            $defaults['height'] = $height; 
            $slider_height = $height; } else { $height = $defaults['height']; }
        if ( $width != '' ) { $slider_width = intval( $width ); }
        
        // Setup height of slider caption
        $slider_class = '';
        if ( $colabs_options['colabs_slider_magazine_excerpt'] != 'true' ) { $slider_class = 'noexcerpt'; }
        
		// Setup width of slider and images.
		$layout = get_option('colabs_layout');
		$layout_width = get_option('colabs_layout_width');
	
		// Setup the number of posts to show.
		$posts_per_page = $colabs_options['colabs_slider_magazine_entries'];
		if ( $posts_per_page != '' ) { $defaults['posts_per_page'] = $posts_per_page; }
		
		// Setup the excerpt length.
		$excerpt_length = $colabs_options['colabs_slider_magazine_excerpt_length'];
		if ( $excerpt_length != '' ) { $defaults['excerpt_length'] = $excerpt_length; }
		
		//$width = intval( $layout_width );
		
		if ( $width > 0 && $args['width'] == '' ) { $defaults['width'] = $width; }
	
		// Merge the arguments with defaults.
		$args = wp_parse_args( $args, $defaults );
	
		// Get layout manager information.
		if ( get_option( 'colabs_layout_manager_enable' ) == "true" ) {
			$layout_info = CoLabs_Layout::get_layout_info();
			$colabs_layouts = get_option( 'colabs_layout_stored_layouts' );
		
			if ( is_array( $layout_info ) && array_key_exists( 'width_main', $layout_info ) && @$colabs_options['colabs_layout'] != "one-col" ) {
				$args['width'] = $layout_info['gutter'] + $layout_info['width_main'] + $layout_info['gutter'];
			}
		}
				
		if ( ( ( isset($args['width']) ) && ( ( $args['width'] <= 0 ) || ( $args['width'] == '')  ) ) || ( !isset($args['width']) ) ) {	$args['width'] = $slider_width; }
		if ( ( isset($args['height']) ) && ( $args['height'] <= 0 )  ) { $args['height'] = '100'; }
		
		// Allow child themes/plugins to filter these arguments.
		$args = apply_filters( 'colabs_magazine_slider_args', $args );
	
	// Begin setting up HTML output.

	$saved = $wp_query;
    query_posts(array('tag__in' => $tag_array, 'showposts' => $args['posts_per_page']));
	
	if ( have_posts() ) : $count = 0;
         
             $html .= '<div id="magazine-slider" class="row">' . "\n";
             
             $slider_title = $colabs_options['colabs_slider_magazine_title'];
             
             if( $slider_title!='' ){
                $html .= '<h4>'. __( $slider_title ,'colabsthemes') .'</h4>' . "\n"; }

	         $html .= '<div class="flexslider">' . "\n";
             $html .= '<ul class="slides">' . "\n";
             
	        while (have_posts()) : the_post(); global $post; $shownposts[$count] = $post->ID; $count++;
	          
	           $styles = 'width: ' . $args['width'] . 'px;';
				if ( $count >= 2 ) { $styles .= ' display:none;'; }
	
				$url = get_permalink( $post->ID );

                $html .= '<li>';
                
                $img_args = array(
                    'width' => $slider_width,
                    'height' => $slider_height,
                    'return' => 'true',
                );
                
                $html .= colabs_image( $img_args );
                
                $html .= '<div class="caption '. $slider_class .'">' . "\n";
                $html .= '<h3><a href="'. get_permalink() .'">'. get_the_title( $post->ID ) .'</a></h3>' . "\n";
	            if ( $colabs_options['colabs_slider_magazine_excerpt'] == 'true' ) {
                    $html .= '<p>' . colabs_text_trim( get_the_excerpt(), $excerpt_length ) . '</p>' . "\n"; }
                $html .= '</div><!-- /.caption -->' . "\n";
                
                $html .= '</li>' . "\n";
                
	       endwhile; $wp_query = $saved;

            $html .= '</ul><!-- /.slides -->' . "\n";
            $html .= '</div><!-- /.flexslider -->' . "\n";
            $html .= '</div><!-- #magazine-slider -->' . "\n";  
	    
		endif; $wp_query = $saved;
	   
    	if ( get_option( 'colabs_exclude' ) != $shownposts ) { update_option( "colabs_exclude", $shownposts ); } 
	
		if ( $args['echo'] ) {
			echo $html;
		}
		
		return $html;
	
	} // End colabs_slider_magazine()
}

/*-----------------------------------------------------------------------------------*/
/* CoLabs Slider Business */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'colabs_slider_biz' ) ) {
	function colabs_slider_biz( $args = null ) {
		
		global $colabs_options, $post;
		
		// This is where our output will be added.
		$html = '';
		
		// Default slider settings. 
		$defaults = array(
							'id' => 'loopedSlider', 
							'echo' => true, 
							'excerpt_length' => '15', 
							'pagination' => false, 
							'width' => '940', 
							'height' => '350', 
							'order' => 'ASC', 
							'posts_per_page' => '5', 
							'slide_page' => 'all', 
							'use_slide_page' => false
						 );
						 
		// Setup the "Slide Page", if one is set.
		if ( isset( $post->ID ) ) {
			$slide_page = 'all';
			$stored_slide_page = get_post_meta( $post->ID, '_slide-page', true );
			
			if ( $stored_slide_page != '' && $stored_slide_page != 'all' ) {
				$slide_page = $stored_slide_page;
				$defaults['use_slide_page'] = true; // Instruct the slider to apply the necessary conditional.
				$defaults['slide_page'] = $slide_page;
			}
		}
		
		// Setup height of slider.
		$height = $colabs_options['colabs_slider_biz_height'];
		if ( $height != '' ) { $defaults['height'] = $height; }
	
		// Setup width of slider and images.
		$layout = $colabs_options['colabs_layout'];
		if ( !$layout )
			$layout = get_option( 'colabs_layout' ); 
		$layout_width = get_option('colabs_layout_width');
	
		// Setup the number of posts to show.
		$posts_per_page = $colabs_options['colabs_slider_biz_number'];
		if ( $posts_per_page != '' ) { $defaults['posts_per_page'] = $posts_per_page; }

		// Setup the order of posts.
		$post_order = $colabs_options['colabs_slider_biz_order'];
		if ( $post_order != '' ) { $defaults['order'] = $post_order; }
		
		// Setup the excerpt length.
		if ( isset($colabs_options['colabs_slider_biz_excerpt_length']) ) {
			$excerpt_length = $colabs_options['colabs_slider_biz_excerpt_length'];
			if ( $excerpt_length != '' ) { $defaults['excerpt_length'] = $excerpt_length; }
		} 
		
		$width = intval( $layout_width );
		
		if ( $width > 0 && $args['width'] == '' ) { $defaults['width'] = $width; }
	
		// Merge the arguments with defaults.
		$args = wp_parse_args( $args, $defaults );
		
		if ( ( ( isset($args['width']) ) && ( ( $args['width'] <= 0 ) || ( $args['width'] == '')  ) ) || ( !isset($args['width']) ) ) {	$args['width'] = '100'; }
		if ( ( isset($args['height']) ) && ( $args['height'] <= 0 )  ) { $args['height'] = '100'; }
		
		// Allow child themes/plugins to filter these arguments.
		$args = apply_filters( 'colabs_biz_slider_args', $args );
	
		// Setup slider page id's
		$query_args = array(
							'post_type' => 'slide', 
							'order' => $args['order'], 
							'orderby' => 'date', 
							'posts_per_page' => $args['posts_per_page']
						);
		
		if ( $args['use_slide_page'] == true ) {
		
			$query_args['tax_query'] = array( array(
								'taxonomy' => 'slide-page',
								'field' => 'slug',
								'terms' => $args['slide_page']
							) );
		
		}
		
		$slide_query = new WP_Query( $query_args );
		
		if ( ( ! $slide_query->have_posts() ) ) {
			echo '<p class="note">' . __( 'Please add some slider posts using the Slide custom post type.', 'colabsthemes' ) . '</p>';
			return;
		}
		
		if ( ( $slide_query->found_posts <= 1 ) ) {
			echo '<p class="note">' . __( 'Please note that this slider requires 2 or more slides in order to function. Please assign another slide.', 'colabsthemes' ) . '</p>';
			return;
		}
			
		// Setup the slider CSS class.
		$slider_css = '';
		
		if ( @$colabs_options['colabs_slider_pagination'] == 'true' ) {
			$slider_css = ' class="has-pagination"';
		}

	// Begin setting up HTML output.
	
	if ( @$colabs_options['colabs_slider_autoheight'] != 'true' ) {
		 $html .= '<div id="' . $args['id'] . '"' . $slider_css . ' style="height:' . $args['height'] . 'px">' . "\n";
	     $html .= '<div class="container" style="height:' . $args['height'] . 'px">' . "\n";
    } else {
		 $html .= '<div id="' . $args['id'] . '"' . $slider_css . ' style="height:auto;">' . "\n";
	     $html .= '<div class="container" style="height:auto;">' . "\n";
	}

	     
	     if ( @$colabs_options['colabs_slider_autoheight'] != 'true' )
	         $html .= '<div class="slides" style="height:' . $args['height'] . 'px">' . "\n";
	     else
	         $html .= '<div class="slides">' . "\n";
	                
	       	 if ( $slide_query->have_posts() ) { $count = 0; while ( $slide_query->have_posts() ) { $slide_query->the_post(); global $post; $count++;
	
				$styles = 'width: ' . $args['width'] . 'px;';
				if ( $count >= 2 ) { $styles .= ' display:none;'; }
	
	            $html .= '<div id="slide-' . $count . '" class="slide" style="' . $styles . '">' . "\n";                
	
				$type = get_post_meta( $post->ID, 'image', true );
				
				if ( $type ) {
					$url = get_post_meta( $post->ID, 'url', true );
					
					if ( $url ) {
						$html .= '<a href="' . $url . '" title="' . the_title_attribute( array( 'echo' => 0 ) ) . '">' . colabs_image('width=' . $args['width'] . '&height=' . $args['height'] . '&link=img&return=true') . '</a>' . "\n";
					} else {
						$html .= colabs_image( 'width=' . $args['width'] . '&height=' . $args['height'] . '&link=img&return=true' );
					}
					
					$html .= '<div class="content">' . "\n";                 
	                
	                if ( $colabs_options['colabs_slider_biz_title'] == 'true' ) {
	                	if ( $url ) {} else { $url = get_permalink( $post->ID ); }
	                
	                	$html .= '<div class="title"><h2 class="title"><a href="' . $url . '">' . get_the_title( $post->ID ) . '</a></h2></div>' . "\n";
	                }
	                	$content = get_the_content($post->ID);
						$content = do_shortcode($content);

	                	$html .= '<div class="excerpt">' . wpautop( $content ) . '</div>' . "\n";
	                    $html .= '</div>' . "\n";
	                    
	                } else {
	                
	                	$content = get_the_content($post->ID);
						$content = do_shortcode($content);

	                	$html .= '<div class="entry">' . wpautop( $content ) . '</div>' . "\n";                       
	               
	               }
	
	            $html .= '</div>' . "\n";  
	
	        } // End WHILE Loop
	        
	       } // End IF Statement
	        
	        $html .= '</div><!-- /.slides -->' . "\n";
	    $html .= '</div><!-- /.container --> ' . "\n";  
	    
	    $html .= '<a href="#" class="previous"><img src="' . get_template_directory_uri() . '/images/btn-prev-slider.png" alt="&lt;" /></a>' . "\n";
	    $html .= '<a href="#" class="next"><img src="' . get_template_directory_uri() . '/images/btn-next-slider.png" alt="&gt;" /></a>' . "\n";        
	    
	
	$html .= '</div><!-- /#' . $args['id'] . ' -->' . "\n";
	
		if ( $args['echo'] ) {
			echo $html;
		}
		
		return $html;
	
	} // End colabs_slider_biz()
}

/*-----------------------------------------------------------------------------------*/
/* Navigation */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'colabs_nav' ) ) {
	function colabs_nav() {
		global $colabs_options;
		colabs_nav_before();
        ?>

        <div class="topmenu row">
            <?php colabs_nav_inside(); ?>
            
            <?php 
            $feed_url = ''; $rss = '';
            if(get_option("colabs_connect_newsletter_id") != ''){ 
	            $feed_url= 'http://feeds.feedburner.com/'.$colabs_options["colabs_connect_newsletter_id"]; 
	        } else { 
		        $feed_url=get_bloginfo("rss2_url");
		    }
            if( get_option("colabs_connect_rss") == 'true' ){ 
	            $rss='<ul id="%1$s" class="menu-block">%3$s<li class="rss"><a href="'.$feed_url.'">RSS</a></li></ul>';
	        } else { 
		        $rss='<ul id="%1$s" class="menu-block">%3$s</ul>';
		    }
            wp_nav_menu( array(  
                'theme_location'    => 'main-menu', 
                'items_wrap'        => $rss, 
                'container'         => 'div', 
                'container_class'   => 'menu', 
                //'items_wrap'        => '<ul id="%1$s" class="menu-block">%3$s</ul>',
                'fallback_cb'       => 'wp_page_menu'
            )); ?>
            <?php //colabs_dropdown_menu('container_class=top-menu&show_option_none=Navigate to&theme_location=main-menu&fallback_cb=colabs_dropdown_pages');?>
        </div>
        <!--#nav-->

<?php colabs_nav_after();
	} // End colabs_nav()
}

/*-----------------------------------------------------------------------------------*/
/* Add subscription links to the navigation bar */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'colabs_nav_subscribe' ) ) {
	function colabs_nav_subscribe () {
		global $colabs_options;
		
		if ( ( isset( $colabs_options['colabs_nav_rss'] ) ) && ( $colabs_options['colabs_nav_rss'] == 'true' ) ) { ?>
		<ul class="rss fr">
			<?php if ( ( isset( $colabs_options['colabs_subscribe_email'] ) ) && ( $colabs_options['colabs_subscribe_email'] ) ) { ?>
			<li class="sub-email"><a href="<?php echo $colabs_options['colabs_subscribe_email'] ?>" target="_blank"><?php _e( 'Subscribe by Email', 'colabsthemes' ); ?></a></li>
			<?php } ?>
			<li class="sub-rss"><a href="<?php if ( $colabs_options['colabs_feed_url'] ) { echo $colabs_options['colabs_feed_url']; } else { echo get_bloginfo_rss( 'rss2_url' ); } ?>"><?php _e( 'Subscribe to RSS', 'colabsthemes' ); ?></a></li>
		</ul>
		<?php }
	} // End colabs_nav_subscribe()
}

/*-----------------------------------------------------------------------------------*/
/* Post More  */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'colabs_post_more' ) ) {
	function colabs_post_more () {
		
		if ( get_option( 'colabs_disable_post_more' ) != 'true' ) {
		
		$html = '';
		
		if ( get_option('colabs_post_content') == 'excerpt' ) { $html .= '[view_full_article after=" <span class=\'sep\'>&bull;</span>"] '; }
		$html .= '[post_comments]';
		
		$html = apply_filters( 'colabs_post_more', $html );
		
			if ( $html != '' ) {
	?>
		<div class="post-more">   
			<?php
				echo $html;
			?>
		</div>                        	
	<?php
			}
		}
	} // End colabs_post_more()
}

/*-----------------------------------------------------------------------------------*/
/* Video Embed  */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'backbone_get_embed' ) ) {
	function backbone_get_embed() { 
		global $colabs_options;
		
		// Setup height & width of embed
		$width = "650";
		$height = "365";
		$layout = $colabs_options['colabs_layout'];
		$layout_width = get_option( 'colabs_layout_width' );
	
        //get dynamic layout
        $layout_get = backbone_get_layout( $layout, $layout_width );
        $width = $layout_get['width'];
        $height = $layout_get['height'];
	
		$embed = colabs_embed( 'width=' . $width . '&height=' . $height );
	
		if ( $embed != '' ) {
	?>
	
	<div class="post-embed">
		<?php echo $embed; ?>
	</div><!-- /.post-embed -->
	
	<?php 
		}
	} 
}


/*-----------------------------------------------------------------------------------*/
/* Dynamic Image */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'backbone_get_image' ) ) {
	function backbone_get_image( $width = '', $height = '', $use_layout = true ) { 
		global $colabs_options;
		
		// Setup height & width of embed
		if( !isset($width) ) $width = "650";
		if( !isset($height) )$height = "365";
        
        if( $use_layout ){
            $layout = $colabs_options['colabs_layout'];
            $layout_width = get_option( 'colabs_layout_width' );
            //get dynamic layout
            $layout_get = backbone_get_layout( $layout, $layout_width );
            $width = $layout_get['width'];
            $height = $layout_get['height'];
        }
        
		$image = colabs_image( 'width=' . $width . '&height=' . $height . '&return=true');
	
		if ( $image != '' ) {
	?>
	
	<div class="post-image">
		<?php echo $image; ?>
	</div><!-- /.post-image -->
	
	<?php 
		}
	} 
}


/*-----------------------------------------------------------------------------------*/
/* Author Box */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'colabs_author' ) ) {
	function colabs_author() { 
		
		// Author box single post page 
		if ( is_single() && get_option( 'colabs_disable_post_author' ) != 'true' && get_post_type() != 'photoblog' )
			add_action( 'colabs_post_inside_after', 'colabs_author_box', 10 );				

		// Author box author page
		elseif ( is_author() )
			add_action( 'colabs_loop_before', 'colabs_author_box', 10 );				
	
	}
}


/*-----------------------------------------------------------------------------------*/
/* Single Post Author */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'colabs_author_box' ) ) {
	function colabs_author_box() { 
		global $post;
        $author_id = $post->post_author;
?>
<div class="entry-author">
	<span class="profile-image"><?php echo get_avatar( $author_id, '55' ); ?></span>
	<div class="profile-content author-detail">
		<h3><?php printf( esc_attr__( 'About', 'colabsthemes' ).' <a href="%2$s">%1$s</a>', get_the_author_meta( 'display_name', $author_id ), get_author_posts_url( $author_id ) ); ?></h3>
        <p><?php echo get_the_author_meta( 'description', $author_id ); ?>
		<?php if (is_singular()) : ?>
        <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID', $author_id ) ); ?>">
				<?php printf( __( 'View all posts by %s <span class="meta-nav">&rarr;</span>', 'colabsthemes' ), get_the_author_meta( 'display_name', $author_id ) ); ?>
			</a>
		</p>
		<?php endif; ?>
	</div>
	<div class="clear"></div>
</div><!--/.entry-author-->
<?php 
	}
}


/*-----------------------------------------------------------------------------------*/
/* Yoast Breadcrumbs */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('_dep_colabs_breadcrumbs') ) { 
	function _dep_colabs_breadcrumbs() {
		if ( function_exists('yoast_breadcrumb') ) { 
			yoast_breadcrumb('<div id="breadcrumb"><p>','</p></div>');
		}
	}
}

/*-----------------------------------------------------------------------------------*/
/* Backbone Breadcrumbs */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('backbone_breadcrumbs_args') ) { 
	function backbone_breadcrumbs_args() {
		if ( function_exists('colabs_breadcrumbs') ) {
            
        	$defaults = array(
        		'separator' => '&raquo;',
        		'before' => '<span class="breadcrumb-title">' . __( 'You are here:', 'colabsthemes' ) . '</span>',
        		'after' => false,
        		'front_page' => false,
        		'show_home' => __( 'Home', 'colabsthemes' ),
        		'echo' => true
        	);
            
            return $defaults;
		}
	}
}

/*-----------------------------------------------------------------------------------*/
/* Single Post - &Related Posts */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'colabs_single_action' ) ) {
	function colabs_single_action() { 
		
		// single post page 
		if ( is_single() && get_option('colabs_connect_related') == "true" )
			add_action('colabs_post_inside_after', 'colabs_single_related');				

	}
}
/*-----------------------------------------------------------------------------------*/
/* CoLabs Advertisement - colabs_ads */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'colabs_ads' ) ) {
	function colabs_ads() {
        
        //single ad
        if( is_single() ){
            add_action( 'colabs_post_inside_after', 'colabs_ad_gen', 10 );						// Single post navigation
        }

}}
/*-----------------------------------------------------------------------------------*/
/* CoLabs Advertisement - colabs_ad_gen */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'colabs_ad_gen' ) ) {
	function colabs_ad_gen() { 
	   
    global $colabs_options;
    global $post;
    
    //default
    $colabs_ad_single = $colabs_options['colabs_ad_single'];
    $colabs_ad_single_adsense = $colabs_options['colabs_ad_single_adsense'];
    $colabs_ad_single_image = $colabs_options['colabs_ad_single_image'];
    $colabs_ad_single_url = $colabs_options['colabs_ad_single_url'];
    $width = 468;
    $height = 60;
    
    //Single Custom Ad
    $colabs_ad_single_custom = get_post_meta($post->ID, 'colabs_ad_single', true); //none, general_ad, custom_ad
    
    if( $colabs_ad_single_custom == 'custom_ad' ){
        $colabs_ad_single = 'true';
        $colabs_ad_single_adsense = get_post_meta($post->ID, 'colabs_ad_single_adsense', true);
        $colabs_ad_single_image = get_post_meta($post->ID, 'colabs_ad_single_image', true);
        $colabs_ad_single_url = get_post_meta($post->ID, 'colabs_ad_single_url', true);
        }
    
        if ( $colabs_ad_single == 'true' && $colabs_ad_single_custom != 'none' && ( $colabs_ad_single_adsense != '' || $colabs_ad_single_image != '' ) ) { ?>
	    <div id="singlead">
            <?php if ($colabs_ad_single_adsense <> "") { echo stripslashes($colabs_ad_single_adsense);  } else { ?>
                <a href="<?php echo $colabs_ad_single_url; ?>"><img src="<?php echo $colabs_ad_single_image; ?>" width="<?php echo $width; ?>" height="<?php echo $height; ?>" alt="advert" /></a>
            <?php } ?>		   	
        </div><!-- /#topad -->
        <?php }
	}
}
/*-----------------------------------------------------------------------------------*/
/* Share Button - backbone_single_share */
/*-----------------------------------------------------------------------------------*/

if (!function_exists('backbone_single_share')) {
	function backbone_single_share() { 
    
    //single post
    if ( is_single() ){ 
        add_action('colabs_comment_before','colabs_share',10);
    }
}}


/*-----------------------------------------------------------------------------------*/
/* Optional Top Navigation (WP Menus)  */
/*-----------------------------------------------------------------------------------*/
if ( ! function_exists( 'colabs_top_navigation' ) ) {
	function colabs_top_navigation() {

		if ( function_exists('has_nav_menu') && has_nav_menu('main-menu') ) { ?>
		
        <?php colabs_nav_before(); ?>
        
        <div class="topmenu col12">
        
        <?php colabs_nav_inside(); ?>
        
        <?php 
        $feed_url = ''; $rss = '';
        if(get_option("colabs_connect_newsletter_id") != ''){ $feed_url= 'http://feeds.feedburner.com/'.$colabs_options["colabs_connect_newsletter_id"]; }else{ $feed_url=get_bloginfo("rss2_url"); }
        if( get_option("colabs_connect_rss") == 'true' ){ $rss='<ul class="menu">%3$s<li class="rss"><a href="'.$feed_url.'">RSS</a></li></ul>'; }else{ $rss='<ul class="menu">%3$s</ul>'; }
        wp_nav_menu( array( 'theme_location' => 'main-menu', 'items_wrap' => $rss, 'container' => '', 'fallback_cb'=>'wp_page_menu') ); ?>
        <?php colabs_dropdown_menu('container_class=top-menu&show_option_none=Navigate to&theme_location=main-menu&fallback_cb=colabs_dropdown_pages');?>
        </div>
        <!--#nav-->
        
        <?php colabs_nav_after(); ?>
  
	    <?php 
    	}
    } 
}

/*-----------------------------------------------------------------------------------*/
/* Footer Widgetized Areas  */
/*-----------------------------------------------------------------------------------*/

add_action( 'colabs_footer_top', 'colabs_footer_sidebars', 10 );

if ( ! function_exists( 'colabs_footer_sidebars' ) ) {
	function colabs_footer_sidebars() {
		global $colabs_options;
		
		$footer_sidebar_total = 4;
		$has_footer_sidebars = false;
		
		// Check if we have footer sidebars to display.
		for ( $i = 1; $i <= $footer_sidebar_total; $i++ ) {
			if ( colabs_active_sidebar( 'footer-' . $i ) && ( $has_footer_sidebars == false ) ) {
				$has_footer_sidebars = true;
			}
		}
		wp_reset_query();
		// If footer sidebars are available, we're on the "Business" page template and we want to disable them, do so.
		if ( $has_footer_sidebars && is_page_template( 'template-business.php' ) && ( @$colabs_options['colabs_business_disable_footer_widgets'] == 'true' ) ) {
			$has_footer_sidebars = false;
		}
		
		// Lastly, we display the sidebars.
		if ( $has_footer_sidebars ) {
		
			//$total = $colabs_options['colabs_layout_footer_sidebars']; //if ( ! $total ) { $total = $footer_sidebar_total; }
			$total = get_option('colabs_layout_footer_sidebars');
            $total_class = 12 / $total;
?>
	<div id="footer-widgets" class="row col-<?php echo $total; ?>">
	
		<?php $i = 0; while ( $i < $total ) { $i++; ?>			
			<?php if ( colabs_active_sidebar( 'footer-' . $i ) ) { ?>
		<div class="block footer-widget-<?php echo $i; ?> col<?php echo $total_class; ?>">
	    	<?php colabs_sidebar( 'footer-' . $i ); ?>    
		</div>	        
	        <?php } ?>
		<?php } // End WHILE Loop ?>
	    		        
		<div class="clear"></div>
	
	</div><!--/#footer-widgets-->
<?php
		
		} else { // End IF Statement for footer widget
		$feedid=get_option('colabs_connect_newsletter_id');
		?>
		<div id="footer-widgets" class="row col-1 no-widget">
		<div class="block col12">
			<div class="subscribe clearfix">
			<div class="email-updates col3">
				<h3>Email updates</h3>
				<p>SUBSCRIBE TO RECEIVE UPDATES</p>
			</div>
			<form class="feedemail-form col5" action="http://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('http://feedburner.google.com/fb/a/mailverify?uri=<?php echo $feedid; ?>', 'popupwindow', 'scrollbars=no,width=<?php echo $width; ?>,height=<?php echo $height; ?>');return true">
				<input type="text" class="feedemail-input" name="email" placeholder="<?php _e('Your Email Here','colabsthemes'); ?>"/>
				<input type="hidden" value="<?php echo $feedid; ?>" name="uri"/>
				<input type="hidden" name="loc" value="en_US"/>
				<input type="submit" value="<?php _e('Signup','colabsthemes'); ?>" class="feedemail-button"/>
			</form>
			</div><!-- .subscribe -->
		</div>		
		</div>	
		<?php
		}
		
	} // End colabs_footer_sidebars()
}

/*-----------------------------------------------------------------------------------*/
/* Add customisable footer areas */
/*-----------------------------------------------------------------------------------*/

/**
 * Add customisable footer areas.
 *
 * @package CoLabsFramework
 * @subpackage Actions
 */

if ( ! function_exists( 'colabs_footer_left' ) ) { 
 function colabs_footer_left () {
 
 	colabs_do_atomic( 'colabs_footer_left_before' );
 	
 	$html = '';
 	
 	if( get_option('colabs_footer_left') == 'true' ) {
		$html .= stripslashes( get_option('colabs_footer_left_text') );
	} else {
		$html .= '[site_copyright]';
	} // End IF Statement
	
	$html = apply_filters( 'colabs_footer_left', $html );
	
	echo $html;
 	
 	colabs_do_atomic( 'colabs_footer_left_after' );
 
 } // End colabs_footer_left()
}

if ( ! function_exists( 'colabs_footer_right' ) ) {  
 function colabs_footer_right () {
 
	colabs_do_atomic( 'colabs_footer_right_before' );
 	
 	$html = '';
 	
 	if( get_option('colabs_footer_right') == 'true' ) {
		$html .= stripslashes( get_option('colabs_footer_right_text') );
	} else {
		$html .= '[site_credit]';
	} // End IF Statement
	
	$html = apply_filters( 'colabs_footer_right', $html );
	
	echo $html;
 	
 	colabs_do_atomic( 'colabs_footer_right_after' );
 
 } // End colabs_footer_right()
}

/*-----------------------------------------------------------------------------------*/
/* Add customisable post meta */
/*-----------------------------------------------------------------------------------*/

/**
 * Add customisable post meta.
 *
 * Add customisable post meta, using shortcodes,
 * to be added/modified where necessary.
 *
 * @package CoLabsFramework
 * @subpackage Actions
 */

if ( ! function_exists( 'colabs_post_meta' ) ) { 
 function colabs_post_meta() {
 
    $post_info = '';
    
 	if ( is_page() ) { return; }
    
    if( get_post_type() == 'photoblog' ){
        
        //global $post;
        $photoblogcat= get_the_term_list( $post->ID, 'photoblog_category', ' ', ', ', '' );
        
		$post_info .= '<p class="entry-info"> [post_author_posts_link] [post_date format="'.get_option('date_format').'"] <span class="entry-cat categories">'.$photoblogcat.'</span> [post_edit]</p><!--/.entry-info-->';        
        
    } else 
    if( get_post_type() == 'portfolio' ){
        
        global $post;
		$years= get_post_meta($post->ID, 'year_completed',true);
        
		if($years)$years = '<span class="entry-date">'.$years.'</span>';
        
        $portfoliocat = get_the_term_list( $post->ID, 'portfoliotypes', ' ', ', ', '' );
        
        if( $portfoliocat ) $portfoliocat = '<span class="entry-cat categories">'. $portfoliocat .'</span>';
        
		$post_info .= '<p class="entry-info"> [post_author_posts_link] '.$years.' '.$portfoliocat.' [post_edit]</p><!--/.entry-info-->';
		        
    } else {
        
        $post_info .= '<p class="entry-info"> [post_author_posts_link] [post_date format="'.get_option('date_format').'"] [post_categories before=""] [post_edit]</p><!--/.entry-info-->';
        
    }
    
	printf( '<div class="post-meta">%s</div>' . "\n", apply_filters( 'colabs_filter_post_meta', $post_info ) );
 
 } // End colabs_post_meta()
}

/*-----------------------------------------------------------------------------------*/
/* Add Post Thumbnail to Single posts on Archives */
/*-----------------------------------------------------------------------------------*/
 
/**
 * Add Post Thumbnail to Single posts on Archives
 *
 * Add code to the colabs_post_inside_before() hook.
 *
 * @package CoLabsFramework
 * @subpackage Actions
 */
 
if ( ! function_exists( 'colabs_display_post_image' ) ) { 
 function colabs_display_post_image () {
 
 	$display_image = false;
 
 	$width = get_option('colabs_thumb_w');
 	$height = get_option('colabs_thumb_h');
 	$align = get_option('colabs_thumb_align');
 	
 	if ( is_single() && @get_option('colabs_thumb_single') == 'true' ) {
 		$width = get_option('colabs_single_w');
 		$height = get_option('colabs_single_h');
 		$align = get_option('colabs_thumb_align_single');
 		$display_image = true; 
 	}
 
 	if ( get_option('colabs_colabs_tumblog_switch') == 'true' ) { $is_tumblog = colabs_tumblog_test(); } else { $is_tumblog = false; }
 
 	if ( $is_tumblog || ( is_single() && @get_option('colabs_thumb_single') == 'false' ) ) { $display_image = false; }
 
 	if ( $display_image == true and !colabs_embed('') ) { colabs_image('width=' . $width . '&height=' . $height . '&class=thumbnail ' . $align); }
 
 } // End colabs_display_post_image()
}

/*-----------------------------------------------------------------------------------*/
/* Post Inside After */
/*-----------------------------------------------------------------------------------*/
/**
 * Post Inside After
 *
 * Add code to the colabs_post_inside_after() hook.
 *
 * @package CoLabsFramework
 * @subpackage Actions
 */

if ( ! function_exists( 'colabs_post_inside_after_default' ) ) { 
 function colabs_post_inside_after_default () {
 	
 	$post_info ='[post_tags sep=", " before="" after=""]';
	printf( '<p class="entry-info">%s</p>' . "\n", apply_filters( 'colabs_post_inside_after_default', $post_info ) );
 
 } // End colabs_post_inside_after_default()
}

/*-----------------------------------------------------------------------------------*/
/* Modify the default "comment" form field. */
/*-----------------------------------------------------------------------------------*/
/**
 * Modify the default "comment" form field.
 *
 * @package CoLabsFramework
 * @subpackage Filters
 */
 
  add_filter( 'comment_form_field_comment', 'colabs_comment_form_comment', 10 );
 
if ( ! function_exists( 'colabs_comment_form_comment' ) ) { 
 function colabs_comment_form_comment ( $field ) {
 
 	$field = str_replace( '<label ', '<label class="hide" ', $field );
 	$field = str_replace( 'cols="45"', 'cols="50"', $field );
 	$field = str_replace( 'rows="8"', 'rows="10"', $field );
 
 	return $field;
 
 } // End colabs_comment_form_comment()
}

/*-----------------------------------------------------------------------------------*/
/* Add theme default comment form fields. */
/*-----------------------------------------------------------------------------------*/ 
/**
 * Add theme default comment form fields.
 *
 * @package CoLabsFramework
 * @subpackage Filters
 */
 
 add_filter( 'comment_form_default_fields', 'colabs_comment_form_fields', 10 );
 
if ( ! function_exists( 'colabs_comment_form_fields' ) ) { 
 function colabs_comment_form_fields ( $fields ) {
 	
 	$commenter = wp_get_current_commenter();

	$req = get_option( 'require_name_email' );
	$aria_req = ( $req ? " aria-required='true'" : '' );
 	
 	$fields =  array(
		'author' => '<p class="comment-form-author"><input id="author" name="author" type="text" class="txt" tabindex="1" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' />' .
					'<label for="author">' . __( 'Name', 'colabsthemes' ) . ( $req ? ' <span class="required">(' . __( 'required', 'colabsthemes' ) . ')</span>' : '' ) . '</label> ' . '</p>',
		'email'  => '<p class="comment-form-email"><input id="email" name="email" type="text" class="txt" tabindex="2" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' />' . 
					'<label for="email">' . __( 'Email (will not be published)', 'colabsthemes' ) . ( $req ? ' <span class="required">(' . __( 'required', 'colabsthemes' ) . ')</span>' : '' ) . '</label> ' . '</p>',
		'url'    => '<p class="comment-form-url"><input id="url" name="url" type="text" class="txt" tabindex="3" value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" />' .
		            '<label for="url">' . __( 'Website', 'colabsthemes' ) . '</label></p>',
	);
 
 	return $fields;
 
 } // End colabs_comment_form_fields()
}

/*-----------------------------------------------------------------------------------*/
/* Add theme default comment form arguments. */
/*-----------------------------------------------------------------------------------*/ 
/**
 * Add theme default comment form arguments.
 *
 * @package CoLabsFramework
 * @subpackage Filters
 */
 
 add_filter( 'comment_form_defaults', 'colabs_comment_form_args', 10 );
 
if ( ! function_exists( 'colabs_comment_form_args' ) ) { 
 function colabs_comment_form_args ( $args ) {
 
 	$args['label_submit'] = __( 'Submit Comment', 'colabsthemes' );
 	$args['comment_notes_before'] = '';
 	$args['comment_notes_after'] = '';
 	$args['cancel_reply_link'] = __( 'Click here to cancel reply.', 'colabsthemes' );
 
 	return $args;
 
 } // End colabs_comment_form_args()
}

/*-----------------------------------------------------------------------------------*/
/* Activate shortcode compatibility in our new custom areas. */
/*-----------------------------------------------------------------------------------*/  
/**
 * Activate shortcode compatibility in our new custom areas.
 *
 * @package CoLabsFramework
 * @subpackage Filters
 */
 	$sections = array( 'colabs_filter_post_meta', 'colabs_post_inside_after_default', 'colabs_post_more', 'colabs_footer_left', 'colabs_footer_right' );
 
 	foreach ( $sections as $s ) { add_filter( $s, 'do_shortcode', 20 ); }

/*-----------------------------------------------------------------------------------*/
/* colabs_content_templates_magazine() */
/*-----------------------------------------------------------------------------------*/ 
/**
 * colabs_content_templates_magazine()
 *
 * Remove the tumblog content template from the templates
 * to search through, if on the "Magazine" page template.
 *
 * @package CoLabsFramework
 * @subpackage Filters
 */

add_filter( 'colabs_content_templates', 'colabs_content_templates_magazine', 10 );

if ( ! function_exists( 'colabs_content_templates_magazine' ) ) { 
	function colabs_content_templates_magazine ( $templates ) {
	
		global $page_template;
		
		if ( $page_template == 'template-magazine.php' ) {
			foreach ( $templates as $k => $v ) {
				$v = str_replace( '.php', '', $v );
				$bits = explode( '-', $v );
				if ( $bits[1] == 'tumblog' ) {
					unset( $templates[$k] );
				}
			}
		}
		
		return $templates;
	
	} // End colabs_content_templates_magazine()
}

/*-----------------------------------------------------------------------------------*/
/* colabs_feedburner_link() */
/*-----------------------------------------------------------------------------------*/ 
/**
 * colabs_feedburner_link()
 *
 * Replace the default RSS feed link with the Feedburner URL, if one
 * has been provided by the user.
 *
 * @package CoLabsFramework
 * @subpackage Filters
 */
 
add_filter( 'feed_link', 'colabs_feedburner_link', 10 );

if ( ! function_exists( 'colabs_feedburner_link' ) ) { 
	function colabs_feedburner_link ( $output, $feed = null ) {
	
		global $colabs_options;
	
		$default = get_default_feed();
	
		if ( ! $feed ) $feed = $default;
		
		if ( $colabs_options[ 'colabs_feed_url' ] && ( $feed == $default ) && ( ! stristr( $output, 'comments' ) ) ) $output = $colabs_options[ 'colabs_feed_url' ];
	
		return $output;
	
	} // End colabs_feedburner_link()
}
	

/*-----------------------------------------------------------------------------------*/
/* Add video embed or image before post content in single - add_meta_single */
/*-----------------------------------------------------------------------------------*/

if( !function_exists( 'add_meta_single' ) ){
function add_meta_single(){
    global $post;
    $single_top = get_post_meta($post->ID, 'colabs_single_top', true);
    $single_img = colabs_image('return=true');
    $single_embed = colabs_get_embed();
    
	if (is_home()){
		backbone_get_image();
	}else{
		if ( $single_top != '' || $single_top != 'none' ){
			if ($single_top=='single_video' ){
				//get video with dynamic width & height
				backbone_get_embed();
			}elseif($single_top=='single_image' ){
				//get image with dynamic width & height
				backbone_get_image();
			}
		}
    }
    if( get_post_type() == 'portfolio' && ( $single_img != '' || $single_embed != '' ) ){
        if ( $single_embed != '' ){
            //get video with dynamic width & height
            backbone_get_embed();
		}elseif( $single_img != '' ){
            //get image with dynamic width & height
            backbone_get_image();
        }
    }
}}

/*-----------------------------------------------------------------------------------*/
/* Add Portfolio Meta in single_portfolio - add_meta_portfolio */
/*-----------------------------------------------------------------------------------*/

if( !function_exists( 'add_meta_portfolio' ) ){
function add_meta_portfolio(){
    global $post;

    $years= get_post_meta($post->ID, 'year_completed',true);
	$designers= get_post_meta($post->ID, 'designers',true);
	$developers= get_post_meta($post->ID, 'developers',true);
	$producers= get_post_meta($post->ID, 'producers',true);
	$links= get_post_meta($post->ID, 'links',true);
    
    if (($designers != '')||($developers != '')||($producers != '')||($links != '')){
        
        $post_info .= '<div class="portfolio-details"><ul>';
        if($designers)$post_info .= '<li>'. __('Designer : ','colabsthemes') . $designers .'</li>';
        if($developers)$post_info .= '<li>'. __('Developer : ','colabsthemes') . $developers .'</li>';
        if($producers)$post_info .= '<li>'. __('Producer : ','colabsthemes') . $producers .'</li>';
        if($links)$post_info .= '<li>'. __('Link : ','colabsthemes') . '<a href="'. $links .'" target="_blank">'. $links .'</a>' .'</li>';
        $post_info .= '</ul></div>';
        
    }
    
	printf( '%s' . "\n", apply_filters( 'add_meta_portfolio', $post_info ) );
    
}}

/*-----------------------------------------------------------------------------------*/
/* Colabs Advanced Search Form - colabs_form_advanced_search */
/*-----------------------------------------------------------------------------------*/

if( !function_exists( 'colabs_form_advanced_search' ) ){
function colabs_form_advanced_search(){
?>
<script>
/* <![CDATA[ */
jQuery(document).ready(function() {
	var $bb_searchinput = jQuery('#bb-searchinput');
		bbsearchvalue = $bb_searchinput.val();
	
	$bb_searchinput.focus(function(){
		if (jQuery(this).val() === bbsearchvalue) jQuery(this).val("");
	}).blur(function(){
		if (jQuery(this).val() === "") jQuery(this).val(bbsearchvalue);
	});
});
/* ]]> */
</script>

			<div id="bb-search">
				<div id="bb-search-inner" class="clearfix">
					<!--p id="bb-search-title"><span><?php esc_html_e('search this website','colabsthemes'); ?></span></p-->
					<form action="<?php echo home_url(); ?>" method="get" id="bb_search_form">
						<p id="bb-search-word"><input type="text" id="bb-searchinput" name="s" value="<?php esc_attr_e('search this site...','colabsthemes'); ?>" /></p>
						
						<p>
							<label>
								<input type="checkbox" id="bb-inc-posts" name="bb-inc-posts" /> <?php esc_html_e('Posts','colabsthemes'); ?>
							</label>
							<label>
								<input type="checkbox" id="bb-inc-pages" name="bb-inc-pages" /> <?php esc_html_e('Pages','colabsthemes'); ?>
							</label>
							<span class="bb_search_selector">
								<select id="bb-month-choice" name="bb-month-choice">
									<option value="no-choice"><?php esc_html_e('Select a month','colabsthemes'); ?></option>
									<?php 
										global $wpdb, $wp_locale;
										
										$selected = '';
										$query = "SELECT YEAR(post_date) AS `year`, MONTH(post_date) AS `month`, count(ID) as posts FROM $wpdb->posts GROUP BY YEAR(post_date), MONTH(post_date) ORDER BY post_date DESC";
										
										$arcresults = $wpdb->get_results($query);
																											
										foreach ( (array) $arcresults as $arcresult ) {
											if ( isset($_POST['bb-month-choice']) && ( $_POST['bb-month-choice'] == ($arcresult->year . $arcresult->month) ) ) {
												$selected = ' selected="selected"';
											}
											echo "<option value='{$arcresult->year}{$arcresult->month}'{$selected}>{$wp_locale->get_month($arcresult->month)}" . ", {$arcresult->year}</option>";
											if ( $selected <> '' ) $selected = '';
										}
									?>
								</select>
								<?php wp_dropdown_categories('show_option_all=Choose a Category&show_count=1&hierarchical=1&id=bb-cat&name=bb-cat'); ?>
							</span><!-- .bb_search_selector -->
						</p>
						<p>
							<input type="hidden" name="bb_searchform_submit" value="bb_search_process" />
							<input class="bb_search_submit" type="submit" value="<?php esc_attr_e('Submit','colabsthemes'); ?>" id="bb_search_submit" />
						</p>
					</form>
				</div> <!-- end #bb-search-inner -->
			</div> <!-- end #bb-search -->
			<div class="clear"></div>
<?php
}}
/*-----------------------------------------------------------------------------------*/
/* END */
/*-----------------------------------------------------------------------------------*/
?>