<?php
//Remove All Custom Post Type
?>