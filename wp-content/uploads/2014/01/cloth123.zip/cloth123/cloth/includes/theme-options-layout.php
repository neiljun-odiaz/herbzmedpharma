<?php
if (!function_exists('colabs_options_layout')) {
function colabs_options_layout(){
    
    $themename =  get_option( 'colabs_themename' );
    $manualurl =  get_option( 'colabs_manual' );
    $shortname =  'colabs_layout';

    //Version in Backend Head
    $theme_data = get_theme_data( get_template_directory() . '/style.css' );
    $local_version = $theme_data['Version'];

    //More Options
    $options_pixels = array("0px","1px","2px","3px","4px","5px","6px","7px","8px","9px","10px","11px","12px","13px","14px","15px","16px","17px","18px","19px","20px"); 

    $layout_options = array();
    
    /* General Styling */
    
    $layout_options[] = array( "name" => __( 'General Styling', 'colabsthemes' ),
                        "icon" => "styling",
                        "type" => "heading");   
    
     $layout_options[] = array( "name" => __( 'Disable ALL custom styles', 'colabsthemes' ),
                        "desc" => __( 'Check this if you want to disable output of all custom CSS in the theme.', 'colabsthemes' ),
                        "id" => $shortname."_style_disable",
                        "std" => "true",
                        "type" => "checkbox");
                                                        
    $layout_options[] = array( "name" =>  __( 'Background Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for site background or add a hex color code e.g. #e6e6e6', 'colabsthemes' ),
                        "id" => $shortname."_style_bg",
                        "std" => "",
                        "type" => "color");   
    
    $layout_options[] = array( "name" => __( 'Background Image', 'colabsthemes' ),
                        "desc" => __( 'Upload a background image, or specify the image address of your image. (http://yoursite.com/image.png)', 'colabsthemes' ),
                        "id" => $shortname."_style_bg_image",
                        "std" => "",
                        "type" => "upload");    
    
    $layout_options[] = array( "name" => __( 'Background Image Repeat', 'colabsthemes' ),
                        "desc" => __( 'Select how you want your background image to display.', 'colabsthemes' ),
                        "id" => $shortname."_style_bg_image_repeat",
                        "type" => "select",
                        "options" => array( "No Repeat" => "no-repeat", "Repeat" => "repeat","Repeat Horizontally" => "repeat-x", "Repeat Vertically" => "repeat-y" ) );
						
    $layout_options[] = array( "name" => __( 'Link Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for links or add a hex color code e.g. #697e09', 'colabsthemes' ),
                        "id" => $shortname."_link_color",
                        "std" => "",
                        "type" => "color");   
    
    $layout_options[] = array( "name" => __( 'Link Hover Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for links hover or add a hex color code e.g. #697e09', 'colabsthemes' ),
                        "id" => $shortname."_link_hover_color",
                        "std" => "",
                        "type" => "color");                    
    
    $layout_options[] = array( "name" => __( 'Button Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for buttons or add a hex color code e.g. #697e09', 'colabsthemes' ),
                        "id" => $shortname."_button_color",
                        "std" => "",
                        "type" => "color");  
                        
    $layout_options[] = array( "name" => __( 'Font Button Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for font buttons or add a hex color code e.g. #697e09', 'colabsthemes' ),
                        "id" => $shortname."_font_button_color",
                        "std" => "",
                        "type" => "color");                 
    
    $layout_options[] = array( "name" => __( 'General Border Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for general border colors or add a hex color code e.g. #e6e6e6', 'colabsthemes' ),
                        "id" => $shortname."_style_border",
                        "std" => "",
                        "type" => "color");  


    /* General Typography */
    
    $layout_options[] = array( "name" => __( 'General Typography', 'colabsthemes' ),
                        "icon" => "typography",
                        "type" => "heading");    
    
    $layout_options[] = array( "name" => __( 'General Typography', 'colabsthemes' ),
                        "desc" => "",
                        "id" => $shortname."_general_font_notice",
                        "std" => __( 'The general typography options below only control typography not covered by other typography options. You can control specific typography on post title, post content, widget titles etc. in the other sections in the options panel.', 'colabsthemes' ),
                        "type" => "info");
    
    $layout_options[] = array( "name" => __( 'General Text Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for your general text. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_text",
                        "std" => array('size' => '13','unit' => 'px', 'face' => 'Arial','style' => 'normal','color' => '#666'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'H1 Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for header H1. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_h1",
                        "std" => array('size' => '25','unit' => 'px', 'face' => 'adelle','style' => 'normal','color' => '#666'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'H2 Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for header H2. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_h2",
                        "std" => array('size' => '23','unit' => 'px', 'face' => 'adelle','style' => 'normal','color' => '#666'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'H3 Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for header H3. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_h3",
                        "std" => array('size' => '21','unit' => 'px', 'face' => 'adelle','style' => 'normal','color' => '#666'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'H4 Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for header H4. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_h4",
                        "std" => array('size' => '19','unit' => 'px', 'face' => 'adelle','style' => 'normal','color' => '#666'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'H5 Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for header H5. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_h5",
                        "std" => array('size' => '17','unit' => 'px', 'face' => 'adelle','style' => 'normal','color' => '#666'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'H6 Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for header H6. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_h6",
                        "std" => array('size' => '15','unit' => 'px', 'face' => 'adelle','style' => 'normal','color' => '#666'),
                        "type" => "typography");  

    /* Layout */
    
    $layout_options[] = array( "name" => __( 'Layout', 'colabsthemes' ),
                        "icon" => "layout",
                        "type" => "heading");    
    
    $layout_options[] = array( "name" => __( 'Layout Manager', 'colabsthemes' ),
                        "desc" => "",
                        "id" => $shortname."_layout_manager_notice",
                        "class" => "",
                        "std" => __( 'Below you can set the general layout and the number of footer widget area. ', 'colabsthemes' ),
                        "type" => "info");
    
    $layout_options[] = array( "name" => __( 'Site Width', 'colabsthemes' ),
                            "desc" => __( 'Set the total site width in pixels.', 'colabsthemes' ),
                            "id" => $shortname . "_width",
                            "std" => "980px",
                            "class" => "hidden",
                            "type" => "select",
                            "options" => array('1200px' => '1200px' ,'980px' => '980px','960px' => '960px','940px' => '940px','880px' => '880px','760px' => '760px'));                 
    
    $images_dir =  get_template_directory_uri() . '/functions/images/';
    
    $layout_options[] = array( "name" => __( 'Main Layout', 'colabsthemes' ),
                            "desc" => __( 'Select main content and sidebar alignment. Choose between 1, 2 or 3 column layout.', 'colabsthemes' ),
                            "id" => $shortname . "", //colabs_layout
                            "std" => "two-col-left",
                            "type" => "images",
                            "options" => array(
                                'one-col' => $images_dir . '1c.png',
                                'two-col-left' => $images_dir . '2cl.png',
                                'two-col-right' => $images_dir . '2cr.png')
                            );
                            
    
    $url =  get_template_directory_uri() . '/functions/images/';
    $layout_options[] = array( "name" => __( 'Footer Widget Areas', 'colabsthemes' ),
                        "desc" => __( 'Select how many footer widget areas you want to display.', 'colabsthemes' ),
                        "id" => $shortname."_footer_sidebars",
                        "std" => "3",
                        "type" => "images",
                        "options" => array(
                            '0' => $url . 'footer-widgets-0.png',
                            '1' => $url . 'footer-widgets-1.png',
                            '2' => $url . 'footer-widgets-2.png',
                            '3' => $url . 'footer-widgets-3.png',
                            '4' => $url . 'footer-widgets-4.png')
                        );         
    

    /* Header Styling */
    
    $layout_options[] = array( "name" => __( 'Header Styling', 'colabsthemes' ),
                        "icon" => "header",
                        "type" => "heading");    
    
    $layout_options[] = array( "name" => __( 'Header Background Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for header background or add a hex color code e.g. #e6e6e6', 'colabsthemes' ),
                        "id" => $shortname."_header_bg",
                        "std" => "",
                        "type" => "color");   
    
    $layout_options[] = array( "name" => __( 'Header Background Image', 'colabsthemes' ),
                        "desc" => __( 'Upload a background image, or specify the image address of your image (http://yoursite.com/image.png). <br/>Image should be same width as your site width.', 'colabsthemes' ),
                        "id" => $shortname."_header_bg_image",
                        "std" => "",
                        "type" => "upload");  
    
    $layout_options[] = array( "name" => __( 'Header Background Image Repeat', 'colabsthemes' ),
                        "desc" => __( 'Select how you want your background image to display.', 'colabsthemes' ),
                        "id" => $shortname."_header_bg_image_repeat",
                        "type" => "select",
                        "options" => array("No Repeat" => "no-repeat", "Repeat" => "repeat","Repeat Horizontally" => "repeat-x", "Repeat Vertically" => "repeat-y",) );                                                          
    
    $layout_options[] = array( "name" => __( 'Header Border', 'colabsthemes' ),
                        "desc" => __( 'Specify border properties for the header.', 'colabsthemes' ),
                        "id" => $shortname."_header_border",
                        "std" => "",
                        "type" => "border");      
    
    $layout_options[] = array( "name" => __( 'Header Margin Top/Bottom', 'colabsthemes' ),
                        "desc" => __( 'Enter an integer value i.e. 20 for the desired header margin.', 'colabsthemes' ),
                        "id" => $shortname."_header_margin_tb",
                        "std" => "",
                        "type" => array( 
                                        array(  'id' => $shortname. '_header_margin_top',
                                                'type' => 'text',
                                                'std' => '0',
                                                'meta' => __( 'Top', 'colabsthemes' ) ),
                                        array(  'id' => $shortname. '_header_margin_bottom',
                                                'type' => 'text',
                                                'std' => '0',
                                                'meta' => __( 'Bottom', 'colabsthemes' ) )
                                      ));
    $layout_options[] = array( "name" => __( 'Header Padding Top/Bottom', 'colabsthemes' ),
                        "desc" => __( 'Enter an integer value i.e. 20 for the desired header padding.', 'colabsthemes' ),
                        "id" => $shortname."_header_padding_tb",
                        "std" => "",
                        "type" => array( 
                                        array(  'id' => $shortname. '_header_padding_top',
                                                'type' => 'text',
                                                'std' => '40',
                                                'meta' => __( 'Top', 'colabsthemes' ) ),
                                        array(  'id' => $shortname. '_header_padding_bottom',
                                                'type' => 'text',
                                                'std' => '30',
                                                'meta' => __( 'Bottom', 'colabsthemes' ) )
                                      ));
    
    $layout_options[] = array( "name" => __( 'Header Padding Left/Right', 'colabsthemes' ),
                        "desc" => __( 'Enter an integer value i.e. 20 for the desired header padding.', 'colabsthemes' ),
                        "id" => $shortname."_header_padding_lr",
                        "std" => "",
                        "type" => array( 
                                        array(  'id' => $shortname. '_header_padding_left',
                                                'type' => 'text',
                                                'std' => '',
                                                'meta' => __( 'Left', 'colabsthemes' ) ),
                                        array(  'id' => $shortname. '_header_padding_right',
                                                'type' => 'text',
                                                'std' => '',
                                                'meta' => __( 'Right', 'colabsthemes' ) )
                                      ));
    
    $layout_options[] = array( "name" => __( 'Site Title Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for your site title. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_logo",
                        "std" => array('size' => '45','unit' => 'px', 'face' => 'adelle','style' => 'bold','color' => '#333'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'Site Description Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for your site description. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_desc",
                        "std" => array('size' => '10','unit' => 'px', 'face' => 'arial','style' => 'normal','color' => '#aaa'),
                        "type" => "typography");  
    
    /* Post Styling */
    
    $layout_options[] = array( "name" => __( 'Post Styling', 'colabsthemes' ),
                        "icon" => "styling",
                        "type" => "heading");  
    
    $layout_options[] = array( "name" => __( 'Post Title Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for your post title. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_post_title",
                        "std" => array('size' => '23','unit' => 'px', 'face' => 'adelle','style' => 'normal','color' => '#666'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'Post Meta Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for your post meta. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_post_meta",
                        "std" => array('size' => '11','unit' => 'px', 'face' => 'arial','style' => 'normal','color' => '#aaa'),
                        "type" => "typography");
    
    $layout_options[] = array( "name" => __( 'Post Text Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for your post text. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_post_text",
                        "std" => array('size' => '15','unit' => 'px', 'face' => 'arial','style' => 'normal','color' => '#666'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'Post More (bottom) Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for your post bottom text. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_font_post_more",
                        "std" => array('size' => '11','unit' => 'px', 'face' => 'arial','style' => 'normal','color' => '#f00'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'Post More (bottom) Border Top', 'colabsthemes' ),
                        "desc" => __( 'Specify border properties for post more section.', 'colabsthemes' ),
                        "id" => $shortname."_post_more_border_top",
                        "std" => "",
                        "type" => "border");      
    
    $layout_options[] = array( "name" => __( 'Post More (bottom) Border Bottom', 'colabsthemes' ),
                        "desc" => __( 'Specify border properties for post more section.', 'colabsthemes' ),
                        "id" => $shortname."_post_more_border_bottom",
                        "std" => "",
                        "type" => "border");  
    
    $layout_options[] = array( "name" => __( 'Post Author Background Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom background color for the post author section or add a hex color code e.g. #fafafa', 'colabsthemes' ),
                        "id" => $shortname."_post_author_bg",
                        "std" => "#f2f2f2",
                        "type" => "color");    
    
    $layout_options[] = array( "name" => __( 'Post Author Border Top', 'colabsthemes' ),
                        "desc" => __( 'Specify border properties for post author section.', 'colabsthemes' ),
                        "id" => $shortname."_post_author_border_top",
                        "std" => "",
                        "type" => "border");      
    
    $layout_options[] = array( "name" => __( 'Post Author Border Bottom', 'colabsthemes' ),
                        "desc" => __( 'Specify border properties for post author section.', 'colabsthemes' ),
                        "id" => $shortname."_post_author_border_bottom",
                        "std" => "",
                        "type" => "border");   
    
    $layout_options[] = array( "name" => __( 'Comments Background Color (even threads)', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom background color for the post comments even threads or add a hex color code e.g. #fafafa', 'colabsthemes' ),
                        "id" => $shortname."_post_comments_bg",
                        "std" => "",
                        "type" => "color");  

    $layout_options[] = array( "name" => __( 'Comments Background Color (odd threads)', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom background color for the post comments odd threads or add a hex color code e.g. #fafafa', 'colabsthemes' ),
                        "id" => $shortname."_post_comments_bg_odd",
                        "std" => "",
                        "type" => "color");
    
    $layout_options[] = array( "name" => __( 'Page Navigation Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for your Page Navigation text. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_pagenav_font",
                        "std" => array('size' => '13','unit' => 'px', 'face' => 'arial','style' => 'normal','color' => '#ddd'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'Page Navigation Background Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for the Page Navigation background or add a hex color code e.g. #fafafa', 'colabsthemes' ),
                        "id" => $shortname."_pagenav_bg",
                        "std" => "#ddd",
                        "type" => "color");    
    
    $layout_options[] = array( "name" => __( 'Page Navigation Border Top', 'colabsthemes' ),
                        "desc" => __( 'Specify border properties for Page Navigation section.', 'colabsthemes' ),
                        "id" => $shortname."_pagenav_border_top",
                        "std" => "",
                        "type" => "border");      
    
    $layout_options[] = array( "name" => __( 'Page Navigation Border Bottom', 'colabsthemes' ),
                        "desc" => __( 'Specify border properties for Page Navigation section.', 'colabsthemes' ),
                        "id" => $shortname."_pagenav_border_bottom",
                        "std" => "",
                        "type" => "border");      
    
      
    
    /* Widget Styling */
    
    $layout_options[] = array( "name" => __( 'Widget Styling', 'colabsthemes' ),
                        "icon" => "styling",
                        "type" => "heading");  
      
    
    $layout_options[] = array( "name" => __( 'Widget Border', 'colabsthemes' ),
                        "desc" => __( 'Specify border properties for widgets.', 'colabsthemes' ),
                        "id" => $shortname."_widget_border",
                        "std" => "",
                        "type" => "border");      
    
    
    $layout_options[] = array( "name" => __( 'Widget Title', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for the widget title. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_widget_font_title",
                        "std" => array('size' => '21','unit' => 'px', 'face' => 'adelle','style' => 'normal','color' => '#666'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'Widget Title Bottom Border', 'colabsthemes' ),
                        "desc" => __( 'Specify border property for the widget title.', 'colabsthemes' ),
                        "id" => $shortname."_widget_title_border",
                        "std" => "",
                        "type" => "border");      
    
    $layout_options[] = array( "name" => __( 'Widget Text', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for the widget text. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_widget_font_text",
                        "std" => array('size' => '13','unit' => 'px', 'face' => 'arial','style' => 'normal','color' => '#666'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'Widget Rounded Corners', 'colabsthemes' ),
                        "desc" => __( 'Set amount of pixels for border radius (rounded corners). Will only show in CSS3 compatible browser.', 'colabsthemes' ),
                        "id" => $shortname."_widget_border_radius",
                        "type" => "select",
                        "options" => $options_pixels);  
    
    $layout_options[] = array( "name" => __( 'Tabs Widget Background color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for the tabs widget or add a hex color code e.g. #cccccc', 'colabsthemes' ),
                        "id" => $shortname."_widget_tabs_bg",
                        "std" => "#eee",
                        "type" => "color");     
    
    $layout_options[] = array( "name" => __( 'Tabs Widget Inside Background Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for the tabs widget or add a hex color code e.g. #cccccc', 'colabsthemes' ),
                        "id" => $shortname."_widget_tabs_bg_inside",
                        "std" => "#fff",
                        "type" => "color");     
    
    $layout_options[] = array( "name" => __( 'Tabs Widget Title', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for the widget text. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_widget_tabs_font",
                        "std" => array('size' => '10','unit' => 'px', 'face' => 'arial','style' => 'normal','color' => '#333'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'Tabs Widget Meta / Tabber Font', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for the widget text. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_widget_tabs_font_meta",
                        "std" => array('size' => '10','unit' => 'px', 'face' => 'arial','style' => 'normal','color' => '#333'),
                        "type" => "typography");  
    
    /* Footer Styling */
    
    $layout_options[] = array( "name" => __( 'Footer Styling', 'colabsthemes' ),
                        "icon" => "footer",
                        "type" => "heading");    
    
    $layout_options[] = array( "name" => __( 'Footer Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for your footer. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_footer_font",
                        "std" => array('size' => '11','unit' => 'px', 'face' => 'arial','style' => 'normal','color' => '#666'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'Footer Background', 'colabsthemes' ),
                        "desc" => __( 'Select the background color you want for your footer.', 'colabsthemes' ),
                        "id" => $shortname."_footer_bg",
                        "std" => "",
                        "type" => "color");  
    
    $layout_options[] = array( "name" => __( 'Footer Border Top', 'colabsthemes' ),
                        "desc" => __( 'Specify top border properties for the footer.', 'colabsthemes' ),
                        "id" => $shortname."_footer_border_top",
                        "std" => array('width' => '1px', 'style' => 'solid', 'color' => '#ddd'),
                        "type" => "border");      
    
    $layout_options[] = array( "name" => __( 'Footer Border Bottom', 'colabsthemes' ),
                        "desc" => __( 'Specify bottom border properties for the footer.', 'colabsthemes' ),
                        "id" => $shortname."_footer_border_bottom",
                        "std" => "",
                        "type" => "border");      
    
    $layout_options[] = array( "name" => __( 'Footer Border Left/Right', 'colabsthemes' ),
                        "desc" => __( 'Specify left/right border properties for the footer.', 'colabsthemes' ),
                        "id" => $shortname."_footer_border_lr",
                        "std" => "",
                        "type" => "border");      
    
    $layout_options[] = array( "name" => __( 'Footer Rounded Corners', 'colabsthemes' ),
                        "desc" => __( 'Set amount of pixels for border radius (rounded corners). Will only show in CSS3 compatible browser.', 'colabsthemes' ),
                        "id" => $shortname."_footer_border_radius",
                        "type" => "select",
                        "options" => $options_pixels);   

    $layout_options[] = array( "name" => __( 'Footer Padding Left/Right', 'colabsthemes' ),
                        "desc" => __( 'Enter an integer value i.e. 20 for the desired footer padding.', 'colabsthemes' ),
                        "id" => $shortname."_footer_padding_lr",
                        "std" => "",
                        "type" => array( 
                                        array(  'id' => $shortname. '_footer_padding_left',
                                                'type' => 'text',
                                                'std' => '',
                                                'meta' => __( 'Left', 'colabsthemes' ) ),
                                        array(  'id' => $shortname. '_footer_padding_right',
                                                'type' => 'text',
                                                'std' => '',
                                                'meta' => __( 'Right', 'colabsthemes' ) )
                                      ));                       

    /* Navigation Styling */
                    
    $layout_options[] = array( "name" => __( 'Navigation Styling', 'colabsthemes' ),
                        "icon" => "styling",
                        "type" => "heading");    
    
    $layout_options[] = array( "name" => __( 'Show Subscribe Link', 'colabsthemes' ),
                        "desc" => __( 'Show the Subscribe to RSS link in right navigation.', 'colabsthemes' ),
                        "id" => $shortname."_nav_rss",
                        "std" => "true",
                        "type" => "checkbox");     
    
    $layout_options[] = array( "name" => __( 'Background Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for the navigation background or add a hex color code e.g. #cccccc', 'colabsthemes' ),
                        "id" => $shortname."_nav_bg",
                        "std" => "#333",
                        "type" => "color");     
    
    $layout_options[] = array( "name" => __( 'Navigation Font Style', 'colabsthemes' ),
                        "desc" => __( 'Select the typography you want for your navigation. <br />* non web-safe font.', 'colabsthemes' ),
                        "id" => $shortname."_nav_font",
                        "std" => array('size' => '14','unit' => 'px', 'face' => 'arial','style' => 'normal','color' => '#fff'),
                        "type" => "typography");  
    
    $layout_options[] = array( "name" => __( 'Hover Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for the navigation hover effect or add a hex color code e.g. #eeeeee', 'colabsthemes' ),
                        "id" => $shortname."_nav_hover",
                        "std" => "",
                        "type" => "color");
                        
    $layout_options[] = array( "name" => __( 'Current Menu Item Color', 'colabsthemes' ),
                        "desc" => __( 'Pick a custom color for highlighting the current menu item in the navigation, or add a hex color code e.g. #eeeeee', 'colabsthemes' ),
                        "id" => $shortname."_nav_currentitem",
                        "std" => "#333",
                        "type" => "color"); 
    
    $layout_options[] = array( "name" => __( 'Border Top', 'colabsthemes' ),
                        "desc" => __( 'Specify border properties for the navigation.', 'colabsthemes' ),
                        "id" => $shortname."_nav_border_top",
                        "std" => "",
                        "type" => "border");      
    
    $layout_options[] = array( "name" => __( 'Border Bottom', 'colabsthemes' ),
                        "desc" => __( 'Specify border properties for the navigation.', 'colabsthemes' ),
                        "id" => $shortname."_nav_border_bot",
                        "std" => "",
                        "type" => "border");      
    
    $layout_options[] = array( "name" => __( 'Border Left/Right', 'colabsthemes' ),
                        "desc" => __( 'Specify border properties for the navigation.', 'colabsthemes' ),
                        "id" => $shortname."_nav_border_lr",
                        "std" => "",
                        "type" => "border");      
    
    $layout_options[] = array( "name" => __( 'Navigation Rounded Corners', 'colabsthemes' ),
                        "desc" => __( 'Set amount of pixels for border radius (rounded corners). Will only show in CSS3 compatible browser.', 'colabsthemes' ),
                        "id" => $shortname."_nav_border_radius",
                        "type" => "select",
                        "options" => $options_pixels); 
    
    

if ( get_option('colabs_layout_template') != $layout_options) update_option('colabs_layout_template',$layout_options);      

//fix colabs_width
update_option($shortname . "_width","980px");

} // END colabs_options_layout()
} // END function_exists()

add_action('admin_head','colabs_options_layout');


?>
