/**
 * jQuery Mobile Menu 
 * Turn unordered list menu into dropdown select menu
 * version 1.0(31-OCT-2011)
 * 
 * Built on top of the jQuery library
 *   http://jquery.com
 * 
 * Documentation
 *   http://github.com/mambows/mobilemenu
 */
(function(a){a.fn.mobileMenu=function(b){var c={defaultText:"Navigate to...",className:"select-menu",subMenuClass:"sub-menu",subMenuDash:"–"},d=a.extend(c,b);this.each(function(){var b=a(this),c;b.find("ul").addClass(d.subMenuClass);a("<select />",{"class":d.className}).insertAfter(b);c=b.next("."+d.className);a("<option />",{value:"#",text:d.defaultText}).appendTo(c);b.find("a").each(function(){var b=a(this),e=" "+b.text(),f=b.parents("."+d.subMenuClass),g=f.length,h;if(b.parents("ul").hasClass(d.subMenuClass)){h=Array(g+1).join(d.subMenuDash);e=h+e}a("<option />",{value:this.href,html:e,selected:this.href==window.location.href}).appendTo(c)});a("."+d.className).change(function(){var b=a(this).val();if(b!=="#"){window.location.href=a(this).val()}})});return this}})(jQuery);


(function($){
$(document).ready(function(){

  /* -----------------------------------------------------------------
    Mobile Menu
  ------------------------------------------------------------------*/
  $('.navigation .menu').mobileMenu();

	/* -----------------------------------------------------------------
    Jquery Sooperfish Menu
	------------------------------------------------------------------*/
	$('.navigation .menu')
		.addClass('sf-menu')
		.sooperfish({
			hoverClass : 'sf-hover',
			animationShow : {height:'show'},
			speedShow : 200,
			delay:500,
			animationHide : {height:'hide'},
			speedHide : 200,
			autoArrows : true,
			dualColumn: 1000,
			tripleColumn: 1000
		});

	/* -----------------------------------------------------------------
    Jquery Flex slider
	------------------------------------------------------------------*/
	$('.flexslider').flexslider({
		animation: 'slide',
		controlsContainer: '.flex-container'
	});

  /* -----------------------------------------------------------------
    Shopping Cart
  ------------------------------------------------------------------*/
  $('.arrow-cart').hover(function(){
    $('.top-cart', this).stop(true, true).fadeIn(400);
  }, function(){
    $('.top-cart', this).stop(true, true).fadeOut(400);
  });

  /* -----------------------------------------------------------------
    Script fallback for nth-child
  ------------------------------------------------------------------*/
  $('.homepost .col6:nth-child(2n+3)').addClass('alpha');
  $('.product-list .column:nth-child(5n+6), .product-list .column:first').addClass('alpha');

});
})(jQuery);