<?php get_header(); 
global $colabs_posttype,$colabs_taxonomy,$plugin;?>
<?php colabs_content_before(); ?>
<div class="bg-main container">
	<div class="row">
		<div class="main columns col12">
			<?php if($plugin!='wpsc'){?>
				<?php colabs_main_before(); ?>
				<div class="content column col9  <?php colabs_post_class(); ?>">
					<?php colabs_loop_before();?>
					<?php if ( have_posts() ):?>
					
						<?php while ( have_posts() ) : the_post();?>
						<?php colabs_get_template_part( 'content', get_post_type() );?>
						<?php endwhile;?>

					<?php endif;?>
					<?php colabs_loop_after();?>
				</div><!-- .content -->
				<?php colabs_main_after(); ?>
				<?php get_sidebar(); ?>
			<?php }else{
				if(is_page('products-page')){
				while ( have_posts() ) : the_post();
				the_content();
				endwhile;
				}else{?>
				<?php colabs_main_before(); ?>
				<div class="content column col9  <?php colabs_post_class(); ?>">
					<?php colabs_loop_before();?>
					<?php if ( have_posts() ):?>
					
						<?php while ( have_posts() ) : the_post();?>
						<?php colabs_get_template_part( 'content', get_post_type() );?>
						<?php endwhile;?>

					<?php endif;?>
					<?php colabs_loop_after();?>
				</div><!-- .content -->
				<?php colabs_main_after(); ?>
				<?php get_sidebar(); ?>
				<?php }
			}
			?>
		</div><!-- .main -->
	</div><!-- .container -->
</div><!-- .bg-main -->
<?php colabs_content_after(); ?>

<?php get_footer(); ?>