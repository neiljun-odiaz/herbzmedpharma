<?php
get_header(); global $colabs_options;
?>
<?php colabs_content_before(); ?>
<div class="bg-main container">
	<div class="row">
		<div class="main columns col12">
			<?php colabs_main_before(); ?>
			<div class="content column col9  <?php colabs_post_class(); ?>">
				<h1><?php dynamictitles();?></h1>
				<?php colabs_loop_before();
				if ( have_posts() ) { $count = 0;
				while ( have_posts() ) { the_post(); $count++; // start have_posts 
				$title_before = '<h1 class="entry-title">';
				 $title_after = '</h1>';
				 
				 if ( ! is_single() ) {
				 
					$title_before = '<h2 class="entry-title">';
					$title_after = '</h2>';
				 
					$title_before = $title_before . '<a href="' . get_permalink( get_the_ID() ) . '" rel="bookmark" title="' . the_title_attribute( array( 'echo' => 0 ) ) . '">';
					$title_after = '</a>' . $title_after;
				 
				 }
				 
				 $page_link_args = apply_filters( 'colabsthemes_pagelinks_args', array( 'before' => '<div class="page-link">' . __( 'Pages:', 'colabsthemes' ), 'after' => '</div>' ) );
				 
				 colabs_post_before();
				?>
					<div class="entry">
						<?php the_title( $title_before, $title_after ); ?>

						<?php colabs_post_content_before(); ?>

						<div class="entry-content"><?php if ( $colabs_options['colabs_post_content'] == 'content' ) { the_content(__('Read More &rarr;', 'colabsthemes') ); } else { the_excerpt(); } ?></div>
						
						<?php colabs_post_content_after(); ?>
						
						
						<?php
							colabs_post_inside_after();
						?>        

					</div><!--.entry-->
				<?php
				 colabs_post_after();
				} // End WHILE Loop
				} else {
					get_template_part( 'content', 'noposts' );
				} // End IF Statement

				colabs_loop_after();

				colabs_pagenav();
				?>
			</div><!-- .content -->
			<?php colabs_main_after(); ?>
			<?php get_sidebar('blog'); ?>

		</div><!-- .main -->
	</div><!-- .container -->
</div><!-- .bg-main -->
<?php colabs_content_after(); ?>

<?php get_footer(); ?>